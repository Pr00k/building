#!/usr/bin/env python3
# ============================================================================
# Building 2.1.0 - Arabic GTK3 PROJECT BUILDER.
#
# Put your project folder in, pick a target, fill the app fields, press
# build. The tool detects the project type, generates the exact modern
# toolchain command, streams the real build log and drives a REAL progress
# bar (percentages reported by the toolchain itself - never an estimate).
#
# Pages:
#   1) Project : pick the project + auto-detect its type + app fields
#                (name, version, build number, package id, icon, ...)
#   2) Target  : APK / AAB / iOS(IPA) / Windows EXE / MSI / Linux .deb /
#                AppImage + per-target options, including "support old
#                devices / older OS versions" (minSdk / iOS deployment
#                target / 32-bit Windows).
#   3) Build   : the equivalent command (full transparency), live log,
#                REAL progress bar, open output folder.
#   4) Update  : UPDATE CENTER - search button + auto check + a center of
#                screen "update available" card + REAL progress bar while
#                downloading/installing (GitHub is the update server).
#   5) About   : toolchain doctor, log viewer, about.
#
# Pinned toolchain versions live in toolchains.json (data, not code) so an
# update can refresh them without touching this file.
#
# Stack: PyGObject (GTK3) + stdlib. PURE ASCII SOURCE - every Arabic string
#        lives in /usr/share/building/ui_ar.json.
# ============================================================================
import json, os, re, shutil, socket, subprocess, sys, tarfile, threading, time, traceback, zipfile
from datetime import datetime

APP_VERSION = "2.4.0"
APP_NAME = "building"
APP_DIR = os.path.dirname(os.path.abspath(__file__))
SHARE_DIR = os.path.normpath(os.path.join(APP_DIR, "..", "..", "share",
                                          "building"))
CONFIG_DIR = os.path.expanduser("~/.config/building")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")
LOG_FILE = os.path.join(CONFIG_DIR, "app.log")
LAUNCHER = "/usr/bin/building"
SELF_DIR = os.path.expanduser("~/.local/share/building")
UPDATE_DEB_TMP = os.path.expanduser("~/building_update.deb")
DEFAULT_OUT = os.path.expanduser("~/Building")
LOCALE_CANDIDATES = [
    os.environ.get("BUILDING_LOCALE", ""),
    os.path.join(SELF_DIR, "ui_ar.json"),
    "/usr/share/building/ui_ar.json",
    os.path.join(APP_DIR, "ui_ar.json"),
    os.path.join(SHARE_DIR, "ui_ar.json"),
]
TOOLCHAIN_CANDIDATES = [
    os.environ.get("BUILDING_TOOLCHAINS", ""),
    os.path.join(SELF_DIR, "toolchains.json"),
    "/usr/share/building/toolchains.json",
    os.path.join(APP_DIR, "toolchains.json"),
    os.path.join(SHARE_DIR, "toolchains.json"),
]

# ---------- UPDATE SERVER (the GitHub repo itself) ----------
UPDATE_REF = "arena/01a087ba-building"
REPO = "Pr00k/building"
UPDATE_ENDPOINTS = [
    "https://raw.githubusercontent.com/%s/%s/update.json?t={ts}"
    % (REPO, UPDATE_REF),
    "https://github.com/%s/raw/%s/update.json" % (REPO, UPDATE_REF),
    "https://api.github.com/repos/%s/contents/update.json?ref=%s"
    % (REPO, UPDATE_REF),
    "https://raw.githubusercontent.com/%s/%s/update.json"
    % (REPO, UPDATE_REF),
]
DEB_ENDPOINTS = [
    "https://github.com/%s/raw/%s/{deb}" % (REPO, UPDATE_REF),
    "https://api.github.com/repos/%s/contents/{deb}?ref=%s"
    % (REPO, UPDATE_REF),
    "https://raw.githubusercontent.com/%s/%s/{deb}" % (REPO, UPDATE_REF),
]
UPDATE_HEADERS = {"User-Agent": APP_NAME,
                  "Accept": "application/vnd.github.raw",
                  "Cache-Control": "no-cache",
                  "Pragma": "no-cache"}

# ---------- targets ----------
TARGETS = ["apk", "aab", "ipa", "exe", "msi", "deb", "appimage"]

# Android API level -> human Android version (for "support old devices")
ANDROID_VERSIONS = {16: "4.1", 17: "4.2", 18: "4.3", 19: "4.4", 20: "4.4W",
                    21: "5.0", 22: "5.1", 23: "6.0", 24: "7.0", 25: "7.1",
                    26: "8.0", 27: "8.1", 28: "9", 29: "10", 30: "11",
                    31: "12", 32: "12L", 33: "13", 34: "14", 35: "15", 36: "16"}
IOS_VERSIONS = ["9.0", "10.0", "11.0", "12.0", "13.0", "14.0", "15.0",
                "16.0", "17.0", "18.0"]
WIN_VERSIONS = ["7", "8", "10", "11"]

# Ready-made compatibility profiles (one click = full sensible setup)
COMPAT_PRESETS = ["balanced", "max_old", "modern", "cutting"]
COMPAT_VALUES = {
    "max_old": dict(min_sdk=16, abis=["arm64-v8a", "armeabi-v7a", "x86",
                                      "x86_64"], ios_min="9.0",
                    win_arch="both", win_min="7", legacy=True),
    "balanced": dict(min_sdk=21, abis=["arm64-v8a", "armeabi-v7a"],
                     ios_min="12.0", win_arch="x64", win_min="10",
                     legacy=True),
    "modern": dict(min_sdk=26, abis=["arm64-v8a", "x86_64"], ios_min="15.0",
                   win_arch="x64", win_min="10", legacy=False),
    "cutting": dict(min_sdk=30, abis=["arm64-v8a"], ios_min="17.0",
                    win_arch="x64", win_min="11", legacy=False),
}

# Ready-made advanced signing profiles
SIGN_PRESETS = ["none", "android_release", "ios_distribution", "windows_pfx"]


def safe_index(items, val, d=0):
    try:
        return items.index(val)
    except Exception:
        return d


def android_name(sdk):
    try:
        return "Android %s" % ANDROID_VERSIONS[int(sdk)]
    except Exception:
        return "API %s" % sdk


def compat_preset(name):
    return dict(COMPAT_VALUES.get(name, COMPAT_VALUES["balanced"]))


def sign_preset(name):
    if name == "android_release":
        return {"mode": "release", "sign_kind": "android"}
    if name == "ios_distribution":
        return {"mode": "release", "sign_kind": "ios"}
    if name == "windows_pfx":
        return {"mode": "release", "sign_kind": "win"}
    return {"mode": "debug", "sign_kind": "none"}


PKG_PRESETS = ["com.example.{app}", "com.{dev}.{app}", "io.github.{dev}.{app}",
               "org.{dev}.{app}", "{app}.app", "com.company.{app}"]


def slug(s, default="app"):
    s = re.sub(r"[^a-z0-9]", "", str(s or "").lower())
    return s or default


def gen_package_id(tmpl, spec):
    """Build a valid reverse-DNS package id from a template + spec."""
    app = slug(spec.get("name"), "app")
    dev = slug(spec.get("developer"), "example")
    pid = tmpl.format(app=app, dev=dev)
    pid = re.sub(r"[^a-z0-9.]", "", pid.lower())
    pid = re.sub(r"\.{2,}", ".", pid).strip(".")
    if not pid or "." not in pid:
        pid = "com.example." + app
    return pid


_WIN = None


# ============================================================================
# pure helpers (no GTK - unit-testable)
# ============================================================================
def log(msg):
    try:
        os.makedirs(CONFIG_DIR, exist_ok=True)
        with open(LOG_FILE, "a") as f:
            f.write("%s %s\n" % (datetime.now().strftime("%H:%M:%S"), msg))
    except Exception:
        pass


def _thread_excepthook(args):
    try:
        tb = "".join(traceback.format_exception(
            args.exc_type, args.exc_value, args.exc_traceback))[-1500:]
        log("THREAD-EXC %s: %s" % (getattr(args.exc_type, "__name__", "?"), tb))
        w = _WIN
        if w is not None and getattr(w, "_alive", False):
            w.report_error("thread:" + getattr(args.exc_type, "__name__", "exc"),
                           tb.strip().splitlines()[-1] if tb.strip() else "exc")
    except Exception:
        pass


threading.excepthook = _thread_excepthook

_LOCALE = {}
_TOOLCHAINS = {}


def load_locale():
    global _LOCALE
    for p in LOCALE_CANDIDATES:
        if p and os.path.isfile(p):
            try:
                with open(p, encoding="utf-8") as f:
                    _LOCALE = json.load(f)
                return p
            except Exception as e:
                log("locale load failed %s: %s" % (p, e))
    return None


def tr(k, fb=""):
    return _LOCALE.get(k, fb if fb else k)


def load_toolchains():
    """The pinned "latest known good" toolchain versions (data file)."""
    global _TOOLCHAINS
    for p in TOOLCHAIN_CANDIDATES:
        if p and os.path.isfile(p):
            try:
                with open(p, encoding="utf-8") as f:
                    _TOOLCHAINS = json.load(f)
                return p
            except Exception as e:
                log("toolchains load failed %s: %s" % (p, e))
    return None


def tc(key, default=""):
    if not _TOOLCHAINS:
        load_toolchains()
    return _TOOLCHAINS.get(key, default)


def _ver_gt(a, b):
    def t(v):
        out = []
        for x in str(v).split("."):
            n = ""
            for ch in x:
                if ch.isdigit():
                    n += ch
                else:
                    break
            out.append(int(n) if n else 0)
        while len(out) < 3:
            out.append(0)
        return tuple(out[:3])
    try:
        return t(a) > t(b)
    except Exception:
        return False


def _read(p, default=""):
    try:
        with open(p, encoding="utf-8", errors="replace") as f:
            return f.read()
    except Exception:
        return default


# ============================================================================
# PROJECT DETECTION (pure)
# ============================================================================
def _has(root, name):
    return os.path.exists(os.path.join(root, name))


def _glob(root, pat):
    import glob
    return sorted(glob.glob(os.path.join(root, pat)))


def _pkg_has(root, dep):
    """True if package.json lists `dep` (real check, not a guess)."""
    try:
        with open(os.path.join(root, "package.json"), encoding="utf-8") as f:
            d = json.load(f)
        deps = {}
        deps.update(d.get("dependencies") or {})
        deps.update(d.get("devDependencies") or {})
        return dep in deps
    except Exception:
        return False


# (kind, marker files, evidence globs, optional content predicate)
PROJECT_RULES = [
    ("flutter", ["pubspec.yaml"], ["lib/main.dart"], None),
    ("react_native", ["package.json"], ["app.json", "metro.config.js"],
     lambda p: _pkg_has(p, "react-native")),
    ("capacitor", ["capacitor.config.json"], ["capacitor.config.ts",
                                              "ionic.config.json"], None),
    ("cordova", ["config.xml"], ["platforms/android"], None),
    ("electron", ["package.json"], ["electron-builder.yml",
                                    "electron-builder.json"],
     lambda p: _pkg_has(p, "electron") or _pkg_has(p, "electron-builder")),
    ("godot", ["project.godot"], [], None),
    ("dotnet", [], ["*.csproj", "*.sln", "*.fsproj"], None),
    ("gradle_java", ["build.gradle", "settings.gradle"],
     ["build.gradle.kts", "app/build.gradle", "app/build.gradle.kts"], None),
    ("kivy", ["buildozer.spec"], [], None),
    ("python", ["requirements.txt", "pyproject.toml", "setup.py"],
     ["main.py", "app.py"], None),
    ("web", ["index.html"], [], None),
]

KIND_TARGETS = {
    "flutter": ["apk", "aab", "ipa", "exe", "deb"],
    "react_native": ["apk", "aab", "ipa"],
    "capacitor": ["apk", "aab", "ipa"],
    "cordova": ["apk", "aab", "ipa"],
    "electron": ["exe", "msi", "deb", "appimage"],
    "godot": ["apk", "exe", "deb"],
    "dotnet": ["exe", "msi", "deb"],
    "gradle_java": ["apk", "aab"],
    "kivy": ["apk", "ipa", "exe"],
    "python": ["exe", "deb", "appimage"],
    "web": ["exe", "deb", "appimage"],
}


ARCHIVE_EXTS = (".zip", ".tar", ".tar.gz", ".tgz", ".tar.bz2", ".tbz2",
                ".tar.xz", ".txz", ".7z", ".rar")


def is_archive(path):
    return str(path).lower().endswith(ARCHIVE_EXTS)


def _guard(name):
    p = os.path.normpath(name)
    if p.startswith("..") or os.path.isabs(p):
        raise IOError("unsafe path in archive: %s" % name)


def _single_top(names):
    tops = set()
    for n in names:
        if "/" not in n:
            return None            # a file at the archive root -> no wrapper
        tops.add(n.split("/", 1)[0])
    return tops.pop() if len(tops) == 1 else None


def extract_archive(path, dest=None):
    """Extract zip/tar variants with stdlib; 7z/rar via external tool.

    Returns the project root (the single top-level dir inside the archive,
    or the destination otherwise). Guarded against path traversal.
    """
    if dest is None:
        base = os.path.splitext(os.path.basename(path))[0]
        dest = os.path.join(CONFIG_DIR, "extract", base)
    os.makedirs(dest, exist_ok=True)
    low = path.lower()
    names = []
    if low.endswith(".zip"):
        with zipfile.ZipFile(path) as z:
            for n in z.namelist():
                _guard(n)
            z.extractall(dest)
            names = z.namelist()
    elif low.endswith((".7z", ".rar")):
        tool = "7z" if low.endswith(".7z") else "unrar"
        binp = shutil.which(tool)
        if not binp:
            raise IOError("need %s to open this archive" % tool)
        cmd = ([binp, "x", "-y", "-o" + dest, path] if tool == "7z"
               else [binp, "x", "-y", path, dest + os.sep])
        subprocess.run(cmd, capture_output=True, timeout=600, check=True)
    else:
        with tarfile.open(path) as t:
            for m in t.getmembers():
                _guard(m.name)
            t.extractall(dest)
            names = [m.name for m in t.getmembers()]
    top = _single_top(names)
    return os.path.join(dest, top) if top else dest


def resolve_project(path):
    """dir -> itself; archive -> extracted root; single file -> its folder."""
    if not path:
        return "", "none"
    if os.path.isdir(path):
        return path, "folder"
    if os.path.isfile(path):
        if is_archive(path):
            return extract_archive(path), "archive"
        return os.path.dirname(os.path.abspath(path)), "file"
    return "", "none"


def download_project(url, dest=None):
    """Clone a git URL or download a file/archive; return the local path."""
    if dest is None:
        dest = os.path.join(CONFIG_DIR, "downloads")
    os.makedirs(dest, exist_ok=True)
    url = (url or "").strip()
    low = url.lower()
    if not low:
        raise IOError("empty url")
    if low.endswith(".git") or low.startswith("git@") or "github.com" in low \
            or "gitlab" in low or "bitbucket.org" in low:
        base = url.rstrip("/").rsplit("/", 1)[-1]
        name = re.sub(r"[^a-z0-9_.-]", "_", base[:-4] if base.endswith(".git")
                      else base) or "repo"
        target = os.path.join(dest, name)
        shutil.rmtree(target, ignore_errors=True)
        subprocess.run(["git", "clone", "--depth", "1", url, target],
                       capture_output=True, timeout=1800, check=True)
        return target
    import urllib.request
    fname = url.rstrip("/").rsplit("/", 1)[-1].split("?")[0] or "download"
    fpath = os.path.join(dest, fname)
    req = urllib.request.Request(url, headers={"User-Agent": "building/2.3"})
    with urllib.request.urlopen(req, timeout=300) as r, open(fpath, "wb") as f:
        shutil.copyfileobj(r, f)
    return fpath


def read_manifest(project, kind):
    """Best-effort name/version from the project's manifest file."""
    out = {}
    try:
        if kind in ("flutter", "kivy"):
            p = os.path.join(project, "pubspec.yaml")
            if os.path.exists(p):
                t = open(p, encoding="utf-8", errors="ignore").read()
                m = re.search(r"^name:\s*(.+)$", t, re.M)
                if m:
                    out["name"] = m.group(1).strip()
                m = re.search(r"^version:\s*([0-9][0-9.]*)", t, re.M)
                if m:
                    out["version"] = m.group(1)
        elif kind in ("electron", "capacitor", "react_native", "cordova"):
            p = os.path.join(project, "package.json")
            if os.path.exists(p):
                j = json.load(open(p, encoding="utf-8", errors="ignore"))
                out["name"] = j.get("name") or out.get("name")
                out["version"] = j.get("version") or out.get("version")
        elif kind == "dotnet":
            import glob as _g
            for cs in _g.glob(os.path.join(project, "*.csproj"))[:1]:
                t = open(cs, encoding="utf-8", errors="ignore").read()
                m = re.search(r"<Version>([^<]+)</Version>", t)
                if m:
                    out["version"] = m.group(1)
    except Exception:
        pass
    return out


def auto_configure(spec):
    """Inspect the project and pick the best settings. Returns (updates, notes).
    A local, offline 'smart' engine - no network, no key required."""
    notes = []
    up = {}
    proj = spec.get("project", "")
    d = detect_project(proj)
    kind = d["kind"]
    up["kind"] = kind
    mani = read_manifest(proj, kind)
    name = mani.get("name") or spec.get("name")
    if mani.get("name"):
        up["name"] = mani["name"]
        notes.append("اسم التطبيق من ملفات المشروع: %s" % mani["name"])
    if mani.get("version"):
        up["version"] = mani["version"]
        notes.append("الإصدار من المشروع: %s" % mani["version"])
    cur_pid = spec.get("package_id", "")
    if not cur_pid or cur_pid.startswith("com.example"):
        pid = gen_package_id("com.{dev}.{app}",
                             {"name": name, "developer": spec.get("developer")})
        up["package_id"] = pid
        notes.append("معرّف حزمة مقترح: %s" % pid)
    mobile = ("flutter", "react_native", "capacitor", "cordova", "kivy",
              "godot", "gradle_java")
    if kind in mobile:
        up["target"] = "apk"
        up["compat_preset"] = "balanced"
        up.update(compat_preset("balanced"))
        up["sign_preset"] = "android_release"
        up.update(sign_preset("android_release"))
        notes.append("أندرويد: هدف APK، توافق متوازن (minSdk %s)، توقيع إصدار"
                     % up.get("min_sdk"))
    elif kind == "dotnet":
        up["target"] = "exe"
        up["win_arch"] = "x64"
        up["win_min"] = "10"
        notes.append("ويندوز: EXE بمعمارية x64، أدنى Windows 10")
    elif kind == "electron":
        up["target"] = "exe"
        up["win_arch"] = "x64"
        notes.append("Electron: هدف EXE")
    else:
        notes.append("لم يُحدد نوع واضح — راجع الإعدادات يدويًا")
    return up, notes


def ai_suggest(spec):
    """Optional AI assist. Uses BUILDING_AI_ENDPOINT + BUILDING_AI_KEY
    (OpenAI-compatible) and BUILDING_AI_MODEL (default gpt-6-Astra) when set.
    Returns the model text, or None to fall back to the local auto_configure.
    Never sends anything without a key; fully optional and offline-safe."""
    ep = os.environ.get("BUILDING_AI_ENDPOINT")
    key = os.environ.get("BUILDING_AI_KEY")
    if not ep or not key:
        return None
    import urllib.request
    model = os.environ.get("BUILDING_AI_MODEL", "gpt-6-Astra")
    prompt = ("You are a build expert. For this project spec JSON, reply with "
              "the single best settings as JSON {name,package_id,min_sdk,"
              "target,notes}: " + json.dumps(
                  {k: spec.get(k) for k in
                   ("kind", "name", "project", "target", "package_id")}))
    body = json.dumps({"model": model, "messages": [
        {"role": "user", "content": prompt}]}).encode()
    req = urllib.request.Request(ep, data=body, headers={
        "Content-Type": "application/json", "Authorization": "Bearer " + key})
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            data = json.loads(r.read().decode())
        return data["choices"][0]["message"]["content"]
    except Exception:
        return None


def detect_project(path):
    """Identify the project type from its files. Pure + offline."""
    out = {"path": path, "kind": "unknown", "evidence": [], "targets": [],
           "entry": "", "valid": False}
    if not path or not os.path.isdir(path):
        return out
    out["valid"] = True
    for kind, markers, extras, check in PROJECT_RULES:
        ev = [m for m in markers if _has(path, m)]
        for pat in extras:
            hits = _glob(path, pat)
            if hits:
                ev.append(os.path.basename(hits[0]))
        ev = [x for x in dict.fromkeys(ev) if x]
        if not ev:
            continue
        if check is not None and not check(path):
            continue
        out["kind"] = kind
        out["evidence"] = ev[:4]
        out["targets"] = list(KIND_TARGETS.get(kind, []))
        break
    for cand in ("lib/main.dart", "main.py", "app.py", "Program.cs",
                 "index.js", "main.js", "index.html", "src/Main.cs"):
        if _has(path, cand):
            out["entry"] = cand
            break
    if out["kind"] == "unknown":
        out["targets"] = list(TARGETS)
    return out


def default_spec(path=""):
    load_toolchains()
    return {
        "project": path,
        "src_kind": "folder",
        "kind": "unknown",
        "target": "apk",
        "name": "MyApp",
        "version": "1.0.0",
        "build_number": "1",
        "package_id": "com.example.myapp",
        "developer": "",
        "description": "",
        "icon": "",
        "mode": "release",
        "legacy": True,
        "compat_preset": "balanced",
        "sign_preset": "none",
        "sign_kind": "none",
        "min_sdk": 21,
        "target_sdk": int(tc("android_target_sdk", 36)),
        "abis": ["arm64-v8a", "armeabi-v7a"],
        "ios_min": "12.0",
        "ios_devices": "iphone",
        "ios_cert": "",
        "ios_prov": "",
        "win_arch": "x64",
        "win_min": "10",
        "win_pfx": "",
        "win_installer": "portable",
        "onefile": True,
        "r8": True,
        "split_abis": True,
        "keystore": "",
        "ks_alias": "",
        "out": DEFAULT_OUT,
        "dotnet_tfm": str(tc("dotnet_tfm", "net10.0")),
    }


def spec_problems(spec):
    """Validation the UI shows before building (pure)."""
    errs = []
    if not spec.get("project") or not os.path.isdir(spec.get("project", "")):
        errs.append("no_project")
    if not re.match(r"^\d+\.\d+(\.\d+)?$", str(spec.get("version", ""))):
        errs.append("bad_version")
    if not re.match(r"^[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z0-9_]+){2,}$",
                    str(spec.get("package_id", ""))):
        errs.append("bad_package_id")
    if spec.get("target") in ("apk", "aab") and int(spec.get("min_sdk", 21)) \
            > int(spec.get("target_sdk", 36)):
        errs.append("min_gt_target_sdk")
    if spec.get("target") not in TARGETS:
        errs.append("bad_target")
    return errs


# ============================================================================
# COMMAND GENERATION (pure) - the heart of the tool
# ============================================================================
def legacy_android(spec):
    """What "support old devices" means for Android."""
    if spec.get("legacy"):
        return {"min_sdk": int(spec.get("min_sdk", 21)),
                "abis": ["arm64-v8a", "armeabi-v7a", "x86_64"],
                "why": "android_legacy_on"}
    return {"min_sdk": max(26, int(spec.get("min_sdk", 26))),
            "abis": ["arm64-v8a", "x86_64"],
            "why": "android_legacy_off"}


def legacy_windows(spec):
    if spec.get("legacy") or spec.get("win_arch") == "both":
        return ["win-x64", "win-x86"]
    return ["win-x64"] if spec.get("win_arch", "x64") == "x64" else ["win-x86"]


def required_tools(kind, target):
    base = []
    if kind == "flutter":
        base = ["flutter"]
    elif kind in ("capacitor", "cordova", "electron", "react_native", "web"):
        base = ["node", "npx"]
    elif kind == "godot":
        base = ["godot"]
    elif kind == "dotnet":
        base = ["dotnet"]
    elif kind in ("python", "kivy"):
        base = ["python3"]
    elif kind == "gradle_java":
        base = ["java"]
    if target in ("apk", "aab"):
        if kind not in ("flutter", "gradle_java"):
            base += ["java"]
        base += ["gradle"] if kind == "gradle_java" else []
    if target == "ipa":
        base += ["xcodebuild"]
    if target in ("exe", "msi"):
        if kind in ("python", "kivy", "web"):
            base += ["pyinstaller", "wine"]
        if kind == "electron":
            base += ["wine"]
    return [b for b in dict.fromkeys(base) if b]


def _flutter_platforms(abis):
    m = {"armeabi-v7a": "android-arm", "arm64-v8a": "android-arm64",
         "x86": "android-x86", "x86_64": "android-x64"}
    out = [m[a] for a in abis if a in m]
    return ",".join(out) if out else "android-arm64"


def build_steps(spec):
    """Return the exact commands for (kind, target) - a list of dicts:
    {"argv": [...], "cwd": ..., "why": "reason key"}."""
    kind, target = spec.get("kind"), spec.get("target")
    proj = spec.get("project", ".")
    out = os.path.expanduser(spec.get("out") or DEFAULT_OUT)
    rel = spec.get("mode", "release") == "release"
    steps = []

    def step(argv, why, cwd=None):
        steps.append({"argv": [a for a in argv if a is not None and a != ""],
                      "cwd": cwd or proj, "why": why})

    # ---- Android (APK / AAB) ----
    if target in ("apk", "aab"):
        la = legacy_android(spec)
        if kind == "flutter":
            art = "apk" if target == "apk" else "appbundle"
            step(["flutter", "build", art,
                  "--release" if rel else "--debug",
                  "--build-name=%s" % spec.get("version", "1.0.0"),
                  "--build-number=%s" % spec.get("build_number", "1"),
                  "--target-platform=%s" % _flutter_platforms(la["abis"]),
                  "--split-per-abi" if (target == "apk" and spec.get(
                      "split_abis", True)) else None],
                 "flutter_android")
        elif kind == "gradle_java":
            task = "assembleRelease" if rel else "assembleDebug"
            if target == "aab":
                task = "bundleRelease" if rel else "bundleDebug"
            step(["./gradlew" if os.path.exists(os.path.join(proj, "gradlew"))
                  else "gradle", task, "--console=plain", "--stacktrace",
                  "-PminSdkVersion=%d" % la["min_sdk"],
                  "-Pandroid.enableR8=%s" % ("true" if spec.get("r8", True)
                                             else "false")], "gradle_android")
        elif kind in ("cordova",):
            step(["npx", "cordova", "build", "android",
                  "--release" if rel else "--debug"], "cordova_android")
        elif kind in ("capacitor", "react_native"):
            step(["npx", "cap", "sync", "android"] if kind == "capacitor"
                 else ["npx", "react-native", "bundle", "--platform", "android",
                       "--dev", "false" if rel else "true",
                       "--entry-file", spec.get("entry") or "index.js",
                       "--bundle-output",
                       "android/app/src/main/assets/index.android.bundle",
                       "--assets-dest", "android/app/src/main/res/"],
                 "cap_sync" if kind == "capacitor" else "rn_bundle")
            step(["./gradlew" if os.path.exists(os.path.join(
                     proj, "android", "gradlew")) else "gradle",
                  "assembleRelease" if rel else "assembleDebug",
                  "--console=plain", "-PminSdkVersion=%d" % la["min_sdk"]],
                 "gradle_android", os.path.join(proj, "android"))
        elif kind == "kivy":
            step(["buildozer", "-v", "android",
                  "release" if rel else "debug"], "buildozer_android")
        elif kind == "godot":
            step(["godot", "--headless", "--path", proj, "--export-release",
                  "Android" if rel else "AndroidDebug",
                  os.path.join(out, "%s.apk" % spec.get("name", "app"))],
                 "godot_android")
        else:
            if kind in ("gradle_java", "unknown"):
                step(["gradle", "assembleRelease", "--console=plain"],
                     "gradle_generic")

    # ---- iOS (IPA) ----
    elif target == "ipa":
        if kind == "flutter":
            step(["flutter", "build", "ipa",
                  "--release" if rel else "--debug",
                  "--build-name=%s" % spec.get("version", "1.0.0"),
                  "--build-number=%s" % spec.get("build_number", "1")],
                 "flutter_ios")
        elif kind == "kivy":
            step(["buildozer", "-v", "ios",
                  "release" if rel else "debug"], "buildozer_ios")
        else:
            step(["npx", "cap", "sync", "ios"], "cap_sync_ios")
            step(["xcodebuild", "-workspace", "ios/App/App.xcworkspace",
                  "-scheme", "App", "-configuration",
                  "Release" if rel else "Debug",
                  "-sdk", "iphoneos",
                  "IPHONEOS_DEPLOYMENT_TARGET=%s"
                  % (spec.get("ios_min") or "12.0"),
                  "archive", "-archivePath", os.path.join(out, "App.xcarchive")],
                 "xcode_archive", os.path.join(proj, "ios"))

    # ---- Windows (EXE / MSI) ----
    elif target in ("exe", "msi"):
        rid = legacy_windows(spec)
        if kind == "dotnet":
            for r in rid:
                step(["dotnet", "publish", "-c",
                      "Release" if rel else "Debug",
                      "-r", r, "--self-contained", "true",
                      "-p:Version=%s" % spec.get("version", "1.0.0"),
                      "-p:Product=%s" % spec.get("name", "app"),
                      "-p:TargetFramework=%s"
                      % (spec.get("dotnet_tfm") or "net10.0"),
                      "-p:SupportedOSPlatformVersion=%s.0"
                      % str(spec.get("win_min", "10")),
                      "-o", os.path.join(out, r)], "dotnet_publish")
        elif kind == "electron":
            step(["npx", "electron-builder",
                  "--win", "nsis" if target == "msi" else "portable",
                  "--x64", "--ia32" if "win-x86" in rid else None,
                  "-c.extraMetadata.version=%s"
                  % spec.get("version", "1.0.0")], "electron_win")
        elif kind == "flutter":
            step(["flutter", "build", "windows",
                  "--release" if rel else "--debug"], "flutter_windows")
        elif kind == "godot":
            step(["godot", "--headless", "--path", proj, "--export-release",
                  "Windows Desktop",
                  os.path.join(out, "%s.exe" % spec.get("name", "app"))],
                 "godot_win")
        else:
            entry = spec.get("entry") or "main.py"
            pyi = ["pyinstaller", "--noconfirm", "--clean",
                   "--name", spec.get("name", "app"),
                   "--onefile" if spec.get("onefile", True) else "--onedir",
                   "--windowed",
                   "--icon", spec.get("icon") or None,
                   "--distpath", out,
                   entry]
            if shutil.which("wine"):
                step(["wine", "python", "-m", "PyInstaller"] + pyi[1:],
                     "pyinstaller_wine")
            else:
                step(pyi, "pyinstaller_native")

    # ---- Linux (.deb / AppImage) ----
    elif target == "deb":
        if kind == "electron":
            step(["npx", "electron-builder", "--linux", "deb",
                  "-c.extraMetadata.version=%s"
                  % spec.get("version", "1.0.0")], "electron_deb")
        elif kind == "flutter":
            step(["flutter", "build", "linux",
                  "--release" if rel else "--debug"], "flutter_linux")
        else:
            step(["dpkg-deb", "--build", "--root-owner-group", proj,
                  os.path.join(out, "%s_%s-1_amd64.deb"
                               % (spec.get("name", "app"),
                                  spec.get("version", "1.0.0")))], "dpkg_deb")
    elif target == "appimage":
        step(["npx", "electron-builder", "--linux", "AppImage"]
             if kind == "electron" else
             ["appimagetool", proj, os.path.join(out, "%s.AppImage"
                                                 % spec.get("name", "app"))],
             "appimage")
    return steps


def missing_tools(spec):
    miss = []
    for t in required_tools(spec.get("kind"), spec.get("target")):
        if not shutil.which(t):
            miss.append(t)
    return miss


def artifact_names(spec):
    n, v = spec.get("name", "app"), spec.get("version", "1.0.0")
    t = spec.get("target")
    return {"apk": ["%s-%s-release.apk" % (n, v), "app-release.apk"],
            "aab": ["app-release.aab"],
            "ipa": ["Runner.ipa", "App.ipa"],
            "exe": ["%s.exe" % n, "%s Setup %s.exe" % (n, v)],
            "msi": ["%s-%s.msi" % (n, v)],
            "deb": ["%s_%s-1_amd64.deb" % (n, v)],
            "appimage": ["%s.AppImage" % n]}.get(t, [])


# ============================================================================
# BUILD RUNNER + REAL PROGRESS (pure)
# ============================================================================
PROGRESS_RE = re.compile(r"(\d{1,3})\s*%")


def parse_progress(line):
    """A REAL fraction from the toolchain's own output, or None.

    We only ever forward a number the build tool printed itself (Gradle /
    Flutter / MSBuild / apt). When it printed none we return None and the UI
    pulses the bar instead of inventing a percentage.
    """
    if not line:
        return None
    best = None
    for m in PROGRESS_RE.finditer(line):
        try:
            v = float(m.group(1))
        except Exception:
            continue
        if 0 <= v <= 100:
            best = v
    return best / 100.0 if best is not None else None


def run_steps(steps, on_line=None, on_progress=None, should_stop=None,
              env_extra=None, timeout=7200):
    """Run the generated commands, streaming their output. Returns
    (ok, failed_index, tail_text)."""
    tail = []
    for i, st in enumerate(steps):
        argv = st["argv"]
        if not argv:
            continue
        if on_line:
            on_line("$ " + " ".join(argv), "cmd")
        env = dict(os.environ)
        env.update(env_extra or {})
        try:
            p = subprocess.Popen(argv, cwd=st.get("cwd") or None,
                                 stdout=subprocess.PIPE,
                                 stderr=subprocess.STDOUT, text=True,
                                 bufsize=1, env=env)
        except Exception as e:
            msg = str(e)
            tail.append(msg)
            if on_line:
                on_line(msg, "err")
            return False, i, "\n".join(tail)[-4000:]
        t0 = time.time()
        try:
            for line in p.stdout:
                line = line.rstrip()
                if not line:
                    continue
                tail.append(line)
                if len(tail) > 400:
                    tail.pop(0)
                if on_line:
                    on_line(line, "out")
                f = parse_progress(line)
                if f is not None and on_progress:
                    on_progress(f, line)
                if should_stop is not None and should_stop():
                    p.kill()
                    if on_line:
                        on_line("STOPPED", "err")
                    return False, i, "\n".join(tail)[-4000:]
                if time.time() - t0 > timeout:
                    p.kill()
                    return False, i, "timeout"
            rc = p.wait()
        except Exception as e:
            try:
                p.kill()
            except Exception:
                pass
            tail.append(str(e))
            return False, i, "\n".join(tail)[-4000:]
        if rc != 0:
            if on_line:
                on_line("exit code %d" % rc, "err")
            return False, i, "\n".join(tail)[-4000:]
        if on_progress:
            on_progress((i + 1) / float(len(steps)), "step %d/%d"
                                                % (i + 1, len(steps)))
    return True, -1, "\n".join(tail)[-4000:]


def toolchain_report():
    """Which build tools are installed, and which version (pure)."""
    probes = [("flutter", ["flutter", "--version"]),
              ("java", ["java", "-version"]),
              ("gradle", ["gradle", "--version"]),
              ("dotnet", ["dotnet", "--version"]),
              ("node", ["node", "--version"]),
              ("npx", ["npx", "--version"]),
              ("python3", ["python3", "--version"]),
              ("pyinstaller", ["pyinstaller", "--version"]),
              ("wine", ["wine", "--version"]),
              ("godot", ["godot", "--version"]),
              ("xcodebuild", ["xcodebuild", "-version"]),
              ("dpkg-deb", ["dpkg-deb", "--version"])]
    rows = []
    for name, cmd in probes:
        path = shutil.which(cmd[0])
        ver = ""
        if path:
            try:
                p = subprocess.run(cmd, capture_output=True, text=True,
                                   timeout=25)
                txt = (p.stdout or p.stderr or "").strip().splitlines()
                ver = txt[0][:70] if txt else ""
            except Exception as e:
                ver = str(e)[:60]
        rows.append((name, path or "", ver))
    return rows


# ============================================================================
# UPDATE ENGINE (GitHub is the update server) - real progress, no estimates
# ============================================================================
def upd_parse_manifest(raw):
    import base64
    data = json.loads(raw)
    if isinstance(data, dict) and "content" in data:
        data = json.loads(base64.b64decode(data["content"]).decode("utf-8"))
    if not isinstance(data, dict) or not data.get("version"):
        raise ValueError("bad manifest")
    return data


def upd_fetch_manifest(endpoints=None, headers=None, logger=log, timeout=30):
    import urllib.request
    endpoints = endpoints or UPDATE_ENDPOINTS
    headers = headers or UPDATE_HEADERS
    routes, info = [], None
    ts = str(int(time.time()))
    for url in endpoints:
        u = url.format(ts=ts)
        t0 = time.time()
        try:
            req = urllib.request.Request(u, headers=headers)
            with urllib.request.urlopen(req, timeout=timeout) as r:
                raw = r.read().decode("utf-8", "replace")
            info = upd_parse_manifest(raw)
            routes.append((u, True, int((time.time() - t0) * 1000), ""))
            break
        except Exception as e:
            routes.append((u, False, int((time.time() - t0) * 1000),
                           str(e)[:120]))
            logger("update route failed %s: %s" % (u, e))
    return info, routes


def upd_download(endpoints=None, headers=None, deb="", dest="", logger=log,
                 timeout=300, progress=None, max_bytes=400 * 1024 * 1024,
                 should_stop=None):
    """progress(done_bytes, total_bytes) - REAL counters, never an estimate."""
    import urllib.request
    endpoints = endpoints or DEB_ENDPOINTS
    headers = headers or UPDATE_HEADERS
    if not deb or not dest:
        return False, 0, "no deb/dest"

    def drop():
        try:
            os.remove(dest)
        except Exception:
            pass

    last, total = "", 0
    for url in endpoints:
        u = url.format(deb=deb)
        try:
            req = urllib.request.Request(u, headers=headers)
            with urllib.request.urlopen(req, timeout=timeout) as r, \
                    open(dest, "wb") as f:
                total = 0
                try:
                    expected = int(r.headers.get("Content-Length") or 0)
                except Exception:
                    expected = 0
                while True:
                    if should_stop is not None and should_stop():
                        drop()
                        return False, total, "cancelled"
                    chunk = r.read(1 << 16)
                    if not chunk:
                        break
                    total += len(chunk)
                    if total > max_bytes:
                        raise IOError("reply too large (> %d bytes)"
                                      % max_bytes)
                    f.write(chunk)
                    if progress:
                        progress(total, expected)
            if expected and total != expected:
                last = "truncated (%d/%d bytes)" % (total, expected)
                drop()
                continue
            if total > 1024:
                return True, total, ""
            last = "short reply (%d bytes)" % total
            drop()
        except Exception as e:
            last = str(e)[:200]
            drop()
            logger("update download route failed %s: %s" % (u, e))
    return False, total, last


def upd_is_deb(path):
    try:
        with open(path, "rb") as f:
            return f.read(8) == b"!<arch>\n"
    except Exception:
        return False


SELF_FILES = [
    ("usr/lib/building/building.py", "building.py"),
    ("usr/share/building/toolchains.json", "toolchains.json"),
    ("usr/share/building/ui_ar.json", "ui_ar.json"),
    ("usr/share/building/building.svg", "building.svg"),
]


def upd_apply_data(deb_path, progress=None, logger=log):
    """Server-style in-place update: pull the app's own files out of the new
    .deb into the user's SELF_DIR (no root, no apt, no reinstall). The launcher
    and the resource loaders prefer SELF_DIR, so a restart applies everything.
    Returns (ok, message)."""
    import io
    import tarfile
    try:
        os.makedirs(SELF_DIR, exist_ok=True)
        r = subprocess.run(["dpkg-deb", "--fsys-tarfile", deb_path],
                           capture_output=True)
        if r.returncode != 0:
            return False, r.stderr.decode("utf-8", "ignore")[:300]
        tf = tarfile.open(fileobj=io.BytesIO(r.stdout))
        members = {}
        for m in tf.getmembers():
            members[m.name.lstrip("./")] = m
        done = 0
        for src, dst in SELF_FILES:
            m = members.get(src)
            if not m or not m.isfile():
                continue
            f = tf.extractfile(m)
            if not f:
                continue
            data = f.read()
            tmp = os.path.join(SELF_DIR, dst + ".tmp")
            with open(tmp, "wb") as o:
                o.write(data)
            os.replace(tmp, os.path.join(SELF_DIR, dst))
            done += 1
            if progress:
                progress(done / float(len(SELF_FILES)), dst)
        return done > 0, "updated %d file(s) into %s" % (done, SELF_DIR)
    except Exception as e:
        logger("apply update failed: %s" % e)
        return False, str(e)[:300]


def upd_install_cmd(dest):
    if os.geteuid() == 0:
        return ["apt-get", "install", "-y", dest]
    return ["pkexec", "apt-get", "install", "-y", dest]


def upd_install_run(dest, progress=None, logger=log, timeout=900):
    """Install with REAL apt progress via APT::Status-Fd. Returns
    (ok, tail, saw_progress). saw_progress=False -> the UI must pulse."""
    cmd = upd_install_cmd(dest) + ["-o", "APT::Status-Fd=1"]
    out, saw = [], False
    try:
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE,
                             stderr=subprocess.STDOUT, text=True, bufsize=1)
    except Exception as e:
        return False, str(e)[:400], False
    t0 = time.time()
    try:
        for line in p.stdout:
            line = line.strip()
            if not line:
                continue
            out.append(line)
            if len(out) > 60:
                out.pop(0)
            if line.startswith("pmstatus:"):
                try:
                    pct = float(line.rsplit(":", 1)[1].strip().rstrip("%"))
                except Exception:
                    continue
                saw = True
                if progress:
                    progress(max(0.0, min(1.0, pct / 100.0)), line)
            if time.time() - t0 > timeout:
                p.kill()
                return False, "install timeout", saw
        rc = p.wait()
    except Exception as e:
        try:
            p.kill()
        except Exception:
            pass
        logger("install failed: %s" % e)
        return False, str(e)[:400], saw
    return rc == 0, "\n".join(out)[-400:], saw


def default_config():
    return {"auto_update_check": True, "notify_desktop": True, "last_spec": {}}


def load_config():
    c = default_config()
    try:
        if os.path.isfile(CONFIG_FILE):
            with open(CONFIG_FILE, encoding="utf-8") as f:
                c.update(json.load(f))
    except Exception as e:
        log("config load failed: %s" % e)
    return c


def save_config(c):
    try:
        os.makedirs(CONFIG_DIR, exist_ok=True)
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(c, f, ensure_ascii=False, indent=1)
    except Exception as e:
        log("config save failed: %s" % e)


# ============================================================================
# GTK
# ============================================================================
GTK_OK = False
_ERR = ""
try:
    import gi
    gi.require_version("Gtk", "3.0")
    from gi.repository import Gtk, Gdk, GLib
    GTK_OK = True
except Exception as e:  # pragma: no cover - headless sandbox
    _ERR = str(e)

CSS = b"""
.bld-notify { background-color: #1e222a; border: 1px solid #3d8bfd;
              border-radius: 14px; }
.bld-notify-title { color: #ffffff; font-size: 22px; font-weight: bold; }
.bld-notify-title-ok { color: #63e6a5; }
.bld-notify-title-err { color: #ff8080; }
.bld-notify-body { color: #d6dbe4; font-size: 14px; }
.bld-notify-badge { background-color: #3d8bfd; color: #ffffff;
                    border-radius: 10px; font-weight: bold; }
.bld-card { background-color: #23283090; border-radius: 10px; }
.bld-log { background-color: #14171c; color: #cfe3ff;
           font-family: monospace; }
.bld-ok { color: #63e6a5; font-weight: bold; }
.bld-bad { color: #ff8080; }
"""


if GTK_OK:

    class BuildingWindow(Gtk.Window):

        def __init__(self):
            if not _LOCALE:
                load_locale()
            load_toolchains()
            super().__init__(title=tr("app_title"))
            self._alive = True
            self.timers = []
            self._upd_busy = False
            self._upd_pending = None
            self._building = False
            self._ui_ready = False
            self.spec = default_spec()
            saved = load_config().get("last_spec") or {}
            if isinstance(saved, dict):
                self.spec.update(saved)
            self.config = load_config()
            global _WIN
            _WIN = self

            self.set_default_size(980, 700)
            self.set_position(Gtk.WindowPosition.CENTER)
            if os.path.isfile("/usr/share/building/building.svg"):
                try:
                    self.set_icon_from_file("/usr/share/building/building.svg")
                except Exception:
                    pass
            try:
                prov = Gtk.CssProvider()
                prov.load_from_data(CSS)
                Gtk.StyleContext.add_provider_for_screen(
                    Gdk.Screen.get_default(), prov,
                    Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
            except Exception as e:
                log("css failed: %s" % e)
            st = Gtk.Settings.get_default()
            if st is not None:
                try:
                    st.set_property("gtk-application-prefer-dark-theme", True)
                except Exception:
                    pass

            hdr = Gtk.HeaderBar()
            hdr.set_show_close_button(True)
            hdr.props.title = tr("app_title")
            hdr.props.subtitle = tr("app_subtitle") + "  v" + APP_VERSION
            self.set_titlebar(hdr)

            vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
            self.add(vbox)
            body = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
            sidebar = Gtk.StackSidebar()
            self.stack = Gtk.Stack()
            self.stack.set_transition_type(Gtk.StackTransitionType.CROSSFADE)
            sidebar.set_stack(self.stack)
            body.pack_start(sidebar, False, False, 0)
            sc = Gtk.ScrolledWindow()
            sc.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
            sc.add(self.stack)
            body.pack_start(sc, True, True, 0)
            vbox.pack_start(body, True, True, 0)
            self.statusbar = Gtk.Label(xalign=0.0)
            self.statusbar.set_margin_start(10)
            self.statusbar.set_margin_end(10)
            self.statusbar.set_margin_top(4)
            self.statusbar.set_margin_bottom(4)
            vbox.pack_end(self.statusbar, False, False, 0)

            self.build_project_page()
            self.build_target_page()
            self.build_build_page()
            self.build_update_page()
            self.build_about_page()
            self._ui_ready = True
            self.refresh_compat_hint()

            self.connect("destroy", self.on_destroy)
            if self.config.get("auto_update_check", True):
                self.timers.append(
                    GLib.timeout_add(8000, self._upd_check_later))

        # ---------- helpers ----------
        def toast(self, m):
            if self._alive:
                self.statusbar.set_text(str(m))
                GLib.timeout_add(7000, self.clear_toast)

        def clear_toast(self):
            if self._alive:
                self.statusbar.set_text("")
            return False

        def on_destroy(self, *_a):
            self._alive = False
            for t in self.timers:
                try:
                    GLib.source_remove(t)
                except Exception:
                    pass
            Gtk.main_quit()

        def card(self, title):
            f = Gtk.Frame()
            f.get_style_context().add_class("bld-card")
            for m in ("start", "end"):
                getattr(f, "set_margin_" + m)(8)
            f.set_margin_top(6)
            f.set_margin_bottom(6)
            lb = Gtk.Label(xalign=0.0)
            lb.set_markup("<b>%s</b>" % GLib.markup_escape_text(title))
            lb.set_margin_start(10)
            lb.set_margin_top(4)
            f.set_label_widget(lb)
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            box.set_margin_start(12)
            box.set_margin_end(12)
            box.set_margin_top(4)
            box.set_margin_bottom(10)
            f.add(box)
            return f, box

        def field(self, box, label, value="", tip="", on_change=None,
                  password=False):
            row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            a = Gtk.Label(xalign=0.0, label=label)
            a.set_size_request(190, -1)
            e = Gtk.Entry()
            e.set_text(str(value or ""))
            if tip:
                e.set_tooltip_text(tip)
            if password:
                e.set_visibility(False)
            if on_change:
                e.connect("changed", lambda w: on_change(w.get_text()))
            row.pack_start(a, False, False, 0)
            row.pack_start(e, True, True, 0)
            box.pack_start(row, False, False, 0)
            return e

        def combo(self, box, label, items, active=0, tip="", on_change=None):
            row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            a = Gtk.Label(xalign=0.0, label=label)
            a.set_size_request(190, -1)
            c = Gtk.ComboBoxText()
            for it in items:
                c.append_text(it)
            c.set_active(max(0, min(active, len(items) - 1)))
            if tip:
                c.set_tooltip_text(tip)
            if on_change:
                c.connect("changed", lambda w: on_change(w.get_active()))
            row.pack_start(a, False, False, 0)
            row.pack_start(c, True, True, 0)
            box.pack_start(row, False, False, 0)
            return c

        def check(self, box, label, active=True, tip="", on_change=None):
            c = Gtk.CheckButton(label=label)
            c.set_active(bool(active))
            if tip:
                c.set_tooltip_text(tip)
            if on_change:
                c.connect("toggled", lambda w: on_change(w.get_active()))
            box.pack_start(c, False, False, 0)
            return c

        # ---------- Page 1: PROJECT ----------
        def build_project_page(self):
            page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
            page.set_margin_top(6)

            f, box = self.card(tr("prj_frame"))
            row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            lab = Gtk.Label(xalign=0.0, label=tr("prj_path"))
            lab.set_size_request(190, -1)
            self.chooser = Gtk.FileChooserButton(title=tr("prj_pick"),
                                                 action=Gtk.FileChooserAction.SELECT_FOLDER)
            if self.spec.get("project") and \
                    os.path.isdir(self.spec["project"]):
                try:
                    self.chooser.set_current_folder(self.spec["project"])
                except Exception:
                    pass
            self.chooser.connect("file-set", self.on_project_chosen)
            row.pack_start(lab, False, False, 0)
            row.pack_start(self.chooser, True, True, 0)
            box.pack_start(row, False, False, 0)

            frow = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            fl = Gtk.Label(xalign=0.0, label=tr("prj_or_file"))
            fl.set_size_request(190, -1)
            fl.set_tooltip_text(tr("prj_file_help"))
            self.file_btn = Gtk.FileChooserButton(
                title=tr("prj_file_pick"), action=Gtk.FileChooserAction.OPEN)
            self.file_btn.connect("file-set", self.on_project_file)
            frow.pack_start(fl, False, False, 0)
            frow.pack_start(self.file_btn, True, True, 0)
            box.pack_start(frow, False, False, 0)

            urow = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            ul = Gtk.Label(xalign=0.0, label=tr("prj_url"))
            ul.set_size_request(190, -1)
            ul.set_tooltip_text(tr("prj_url_help"))
            self.e_url = Gtk.Entry()
            self.e_url.set_tooltip_text(tr("prj_url_help"))
            ub = Gtk.Button(label=tr("prj_import"))
            ub.set_tooltip_text(tr("prj_url_help"))
            ub.connect("clicked", self.on_import_url)
            urow.pack_start(ul, False, False, 0)
            urow.pack_start(self.e_url, True, True, 0)
            urow.pack_start(ub, False, False, 0)
            box.pack_start(urow, False, False, 0)

            srow = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            self.b_smart = Gtk.Button(label=tr("prj_smart"))
            self.b_smart.set_tooltip_text(tr("prj_smart_help"))
            self.b_smart.connect("clicked", self.on_smart)
            srow.pack_start(self.b_smart, False, False, 0)
            box.pack_start(srow, False, False, 0)

            self.lbl_kind = Gtk.Label(xalign=0.0)
            self.lbl_kind.set_line_wrap(True)
            self.lbl_kind.set_max_width_chars(64)
            box.pack_start(self.lbl_kind, False, False, 0)
            page.pack_start(f, False, False, 0)

            f2, box2 = self.card(tr("prj_fields"))
            self.e_name = self.field(box2, tr("fld_name"),
                                     self.spec.get("name"),
                                     tr("fld_name_help"), self.set_name)
            self.e_ver = self.field(box2, tr("fld_version"),
                                    self.spec.get("version"),
                                    tr("fld_version_help"), self.set_version)
            self.e_build = self.field(box2, tr("fld_build_number"),
                                      self.spec.get("build_number"),
                                      tr("fld_build_help"), self.set_build)
            self.e_pkg = self.field(box2, tr("fld_package_id"),
                                    self.spec.get("package_id"),
                                    tr("fld_package_help"), self.set_pkg)
            self.c_pkg = self.combo(box2, tr("fld_package_preset"),
                                    ["—"] + PKG_PRESETS, 0,
                                    tr("fld_package_preset_help"),
                                    self.on_pkg_preset)
            self.e_dev = self.field(box2, tr("fld_developer"),
                                    self.spec.get("developer"), "",
                                    self.set_dev)
            self.e_desc = self.field(box2, tr("fld_description"),
                                     self.spec.get("description"), "",
                                     self.set_desc)
            irow = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            il = Gtk.Label(xalign=0.0, label=tr("fld_icon"))
            il.set_size_request(190, -1)
            self.icon_btn = Gtk.FileChooserButton(
                title=tr("fld_icon_pick"),
                action=Gtk.FileChooserAction.OPEN)
            self.icon_btn.connect("file-set", self.on_icon_chosen)
            irow.pack_start(il, False, False, 0)
            irow.pack_start(self.icon_btn, True, True, 0)
            box2.pack_start(irow, False, False, 0)
            page.pack_start(f2, False, False, 0)
            self.stack.add_titled(page, "page_project", tr("tab_project"))
            self.show_detection(detect_project(self.spec.get("project", "")))

        def on_project_chosen(self, w):
            self._set_project(w.get_filename() or "", "folder")

        def on_project_file(self, w):
            """Accepts an archive (zip/tar/7z/rar) or a single source file."""
            self._set_project(w.get_filename() or "", "auto")

        def _set_project(self, p, src_hint):
            if not p:
                return
            try:
                root, kind = resolve_project(p)
            except Exception as e:
                self.notify_center("err", tr("prj_bad_archive"), str(e),
                                   [(tr("up_close"), "", None)])
                return
            if not root:
                return
            if src_hint == "auto":
                src_hint = kind
            self.spec["project"] = root
            self.spec["src_kind"] = src_hint
            self.spec["kind"] = detect_project(root)["kind"]
            cur = self.e_name.get_text().strip()
            if not cur or cur == "MyApp":
                base = os.path.splitext(os.path.basename(p.rstrip("/")))[0] \
                    or "MyApp"
                self.e_name.set_text(base)
                self.spec["name"] = base
                pid = "com.example." + re.sub(r"[^a-z0-9]", "",
                                              base.lower())[:24]
                if pid.count(".") >= 2:
                    self.e_pkg.set_text(pid)
                    self.spec["package_id"] = pid
            self.show_detection(detect_project(root))
            self.save_spec()

        def on_import_url(self, w):
            url = (self.e_url.get_text() or "").strip()
            if not url:
                return
            try:
                self.lbl_kind.set_markup(GLib.markup_escape_text(
                    tr("prj_downloading")))
            except Exception:
                pass

            def work():
                try:
                    p = download_project(url)
                    GLib.idle_add(lambda: self._set_project(p, "auto"))
                except Exception as e:
                    GLib.idle_add(lambda: self.notify_center(
                        "err", tr("prj_bad_url"), str(e),
                        [(tr("up_close"), "", None)]))
            threading.Thread(target=work, daemon=True).start()

        def on_smart(self, w):
            """Advanced auto-configure: inspect the project and inject the best
            settings. Uses optional AI if a key is set, else the local engine."""
            notes = []
            ai = ai_suggest(self.spec)
            if ai:
                notes.append(tr("prj_ai_used"))
                notes.append(str(ai)[:400])
            up, n2 = auto_configure(self.spec)
            notes.extend(n2)
            self.spec.update(up)
            for ent, key in ((getattr(self, "e_name", None), "name"),
                             (getattr(self, "e_pkg", None), "package_id"),
                             (getattr(self, "e_ver", None), "version")):
                try:
                    if ent is not None and key in up:
                        ent.set_text(str(up[key]))
                except Exception:
                    pass
            self.show_detection(detect_project(self.spec.get("project", "")))
            self.save_spec()
            self.notify_center("info", tr("prj_smart_done"),
                               "\n".join(notes) or tr("prj_smart_none"),
                               [(tr("up_close"), "", None)])

        def on_icon_chosen(self, w):
            self.spec["icon"] = w.get_filename() or ""
            self.save_spec()

        def show_detection(self, d):
            self._det = d
            if not d.get("valid"):
                self.lbl_kind.set_markup(
                    '<span foreground="#ffb0b0">%s</span>'
                    % GLib.markup_escape_text(tr("det_none")))
                return
            kind = d["kind"]
            line = tr("det_found") % (tr("kind_" + kind),
                                      ", ".join(d["evidence"]))
            line += "\n" + (tr("det_targets") % ", ".join(
                tr("tgt_" + t) for t in d["targets"]))
            if kind in ("flutter", "react_native", "capacitor", "cordova"):
                line += "\n" + tr("det_modern") % (
                    tc("flutter_latest", "?"), tc("agp", "?"),
                    tc("gradle", "?"), tc("android_build_tools", "?"))
            sk = self.spec.get("src_kind", "")
            if sk in ("folder", "archive", "file"):
                line = tr("prj_src_" + sk) + "\n" + line
            self.lbl_kind.set_markup(GLib.markup_escape_text(line)
                                     .replace("\n", "\n"))
            # preselect a target the project can actually produce
            if self.spec.get("target") not in d["targets"] and d["targets"]:
                self.spec["target"] = d["targets"][0]
                if hasattr(self, "c_target"):
                    try:
                        self.c_target.set_active(
                            TARGETS.index(self.spec["target"]))
                    except Exception:
                        pass

        def set_name(self, v):
            self.spec["name"] = v.strip() or "MyApp"
            self.save_spec()

        def set_version(self, v):
            self.spec["version"] = v.strip()
            self.save_spec()

        def set_build(self, v):
            self.spec["build_number"] = v.strip() or "1"
            self.save_spec()

        def set_pkg(self, v):
            self.spec["package_id"] = v.strip()
            self.save_spec()

        def on_pkg_preset(self, i):
            if not i or i <= 0:
                return
            tmpl = PKG_PRESETS[min(i - 1, len(PKG_PRESETS) - 1)]
            pid = gen_package_id(tmpl, self.spec)
            self.e_pkg.set_text(pid)
            self.spec["package_id"] = pid
            self.save_spec()

        def set_dev(self, v):
            self.spec["developer"] = v.strip()
            self.save_spec()

        def set_desc(self, v):
            self.spec["description"] = v.strip()
            self.save_spec()

        def save_spec(self):
            self.config["last_spec"] = self.spec
            save_config(self.config)

        # ---------- Page 2: TARGET ----------
        def build_target_page(self):
            page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
            page.set_margin_top(6)

            # ---- common ----
            f, box = self.card(tr("tgt_frame"))
            self._desc_common(box, tr("tgt_frame_help"))
            idx = 0
            try:
                idx = TARGETS.index(self.spec.get("target", "apk"))
            except Exception:
                pass
            self.c_target = self.combo(
                box, tr("tgt_target"), [tr("tgt_" + t) for t in TARGETS],
                idx, tr("tgt_target_help"), self.on_target_changed)
            self.c_mode = self.combo(box, tr("tgt_mode"),
                                     [tr("tgt_release"), tr("tgt_debug")],
                                     0 if self.spec.get("mode") == "release"
                                     else 1, tr("tgt_mode_help"),
                                     self.on_mode_changed)
            self.c_compat = self.combo(
                box, tr("tgt_compat_preset"),
                [tr("preset_" + c) for c in COMPAT_PRESETS],
                safe_index(COMPAT_PRESETS, self.spec.get(
                    "compat_preset", "balanced")),
                tr("tgt_compat_preset_help"), self.on_compat_preset)
            orow = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            ol = Gtk.Label(xalign=0.0, label=tr("tgt_out"))
            ol.set_size_request(190, -1)
            self.out_btn = Gtk.FileChooserButton(
                title=tr("tgt_out_pick"),
                action=Gtk.FileChooserAction.SELECT_FOLDER)
            try:
                os.makedirs(self.spec.get("out") or DEFAULT_OUT, exist_ok=True)
                self.out_btn.set_current_folder(self.spec.get("out")
                                                or DEFAULT_OUT)
            except Exception:
                pass
            self.out_btn.connect("file-set", self.on_out_chosen)
            orow.pack_start(ol, False, False, 0)
            orow.pack_start(self.out_btn, True, True, 0)
            box.pack_start(orow, False, False, 0)
            self.lbl_target_desc = Gtk.Label(xalign=0.0)
            self.lbl_target_desc.set_line_wrap(True)
            self.lbl_target_desc.set_max_width_chars(76)
            box.pack_start(self.lbl_target_desc, False, False, 0)
            page.pack_start(f, False, False, 0)

            # ---- Android ----
            self.f_android, ba = self.card(tr("tgt_android"))
            self._desc_common(ba, tr("tgt_android_help"))
            self.legacy = self.check(
                ba, tr("tgt_legacy"), self.spec.get("legacy", True),
                tr("tgt_legacy_help"), self.on_legacy_changed)
            self.lbl_legacy = Gtk.Label(xalign=0.0)
            self.lbl_legacy.set_line_wrap(True)
            self.lbl_legacy.set_max_width_chars(76)
            ba.pack_start(self.lbl_legacy, False, False, 0)
            srow = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            sl = Gtk.Label(xalign=0.0, label=tr("tgt_min_sdk"))
            sl.set_size_request(190, -1)
            sl.set_tooltip_text(tr("tgt_min_sdk_help"))
            self.sdk_scale = Gtk.Scale.new_with_range(
                Gtk.Orientation.HORIZONTAL, 16, 36, 1)
            self.sdk_scale.set_value(int(self.spec.get("min_sdk", 21)))
            self.sdk_scale.set_draw_value(True)
            self.sdk_scale.set_size_request(240, -1)
            self.sdk_scale.connect("value-changed",
                                   lambda w: self.set_min_sdk(
                                       int(w.get_value())))
            srow.pack_start(sl, False, False, 0)
            srow.pack_start(self.sdk_scale, True, True, 0)
            ba.pack_start(srow, False, False, 0)
            self.lbl_android_name = Gtk.Label(xalign=0.0)
            ba.pack_start(self.lbl_android_name, False, False, 0)
            self.split_abis = self.check(
                ba, tr("tgt_split_abis"), self.spec.get("split_abis", True),
                tr("tgt_split_help"), self.on_split_changed)
            self.r8 = self.check(ba, tr("tgt_r8"), self.spec.get("r8", True),
                                 tr("tgt_r8_help"), self.on_r8_changed)
            page.pack_start(self.f_android, False, False, 0)

            # ---- iOS ----
            self.f_ios, bi = self.card(tr("tgt_ios"))
            self._desc_common(bi, tr("tgt_ios_help"))
            self.c_ios = self.combo(bi, tr("tgt_ios_min"), IOS_VERSIONS,
                                    safe_index(IOS_VERSIONS, self.spec.get(
                                        "ios_min", "12.0")),
                                    tr("tgt_ios_min_help"), self.on_ios_min)
            self.c_iosdev = self.combo(
                bi, tr("tgt_ios_devices"),
                [tr("ios_dev_iphone"), tr("ios_dev_ipad"),
                 tr("ios_dev_both")], 0, tr("tgt_ios_devices_help"),
                self.on_ios_devices)
            self.e_ioscert = self.field(bi, tr("sign_ios_cert"),
                                        self.spec.get("ios_cert", ""),
                                        tr("sign_ios_cert_help"),
                                        self.set_ios_cert)
            self.e_iosprov = self.field(bi, tr("sign_ios_prov"),
                                        self.spec.get("ios_prov", ""),
                                        tr("sign_ios_prov_help"),
                                        self.set_ios_prov)
            page.pack_start(self.f_ios, False, False, 0)

            # ---- Windows ----
            self.f_win, bw = self.card(tr("tgt_win"))
            self._desc_common(bw, tr("tgt_win_help"))
            self.c_win = self.combo(bw, tr("tgt_win_arch"),
                                    [tr("arch_x64"), tr("arch_x86"),
                                     tr("arch_both")],
                                    safe_index(["x64", "x86", "both"],
                                               self.spec.get("win_arch",
                                                             "x64")),
                                    tr("tgt_win_arch_help"), self.on_win_arch)
            self.c_winmin = self.combo(bw, tr("tgt_win_min"),
                                       ["Windows %s" % w for w in WIN_VERSIONS],
                                       safe_index(WIN_VERSIONS, self.spec.get(
                                           "win_min", "10")),
                                       tr("tgt_win_min_help"),
                                       self.on_win_min)
            self.c_inst = self.combo(bw, tr("tgt_installer"),
                                     [tr("inst_portable"), tr("inst_nsis"),
                                      tr("inst_msi")], 0,
                                     tr("tgt_installer_help"),
                                     self.on_installer)
            self.onefile = self.check(bw, tr("tgt_onefile"),
                                      self.spec.get("onefile", True),
                                      tr("tgt_onefile_help"),
                                      self.on_onefile_changed)
            page.pack_start(self.f_win, False, False, 0)

            # ---- signing ----
            self.f_sign, bs = self.card(tr("tgt_sign"))
            self._desc_common(bs, tr("tgt_sign_help"))
            self.c_sign = self.combo(
                bs, tr("sign_preset"),
                [tr("signp_" + x) for x in SIGN_PRESETS],
                safe_index(SIGN_PRESETS, self.spec.get(
                    "sign_preset", "none")),
                tr("sign_preset_help"), self.on_sign_preset)
            self.box_sign_android = Gtk.Box(
                orientation=Gtk.Orientation.VERTICAL, spacing=0)
            krow = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            kl = Gtk.Label(xalign=0.0, label=tr("sign_keystore"))
            kl.set_size_request(190, -1)
            kl.set_tooltip_text(tr("sign_keystore_help"))
            self.ks_btn = Gtk.FileChooserButton(
                title=tr("sign_pick"), action=Gtk.FileChooserAction.OPEN)
            self.ks_btn.connect("file-set", self.on_ks_chosen)
            krow.pack_start(kl, False, False, 0)
            krow.pack_start(self.ks_btn, True, True, 0)
            self.box_sign_android.pack_start(krow, False, False, 0)
            self.e_alias = self.field(self.box_sign_android, tr("sign_alias"),
                                      self.spec.get("ks_alias", ""),
                                      tr("sign_alias_help"), self.set_alias)
            bs.pack_start(self.box_sign_android, False, False, 0)
            self.box_sign_win = Gtk.Box(
                orientation=Gtk.Orientation.VERTICAL, spacing=0)
            pfxrow = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            pl = Gtk.Label(xalign=0.0, label=tr("sign_pfx"))
            pl.set_size_request(190, -1)
            pl.set_tooltip_text(tr("sign_pfx_help"))
            self.pfx_btn = Gtk.FileChooserButton(
                title=tr("sign_pfx_pick"), action=Gtk.FileChooserAction.OPEN)
            self.pfx_btn.connect("file-set", self.on_pfx_chosen)
            pfxrow.pack_start(pl, False, False, 0)
            pfxrow.pack_start(self.pfx_btn, True, True, 0)
            self.box_sign_win.pack_start(pfxrow, False, False, 0)
            bs.pack_start(self.box_sign_win, False, False, 0)
            note = Gtk.Label(xalign=0.0)
            note.set_line_wrap(True)
            note.set_max_width_chars(76)
            note.set_text(tr("sign_note"))
            bs.pack_start(note, False, False, 0)
            page.pack_start(self.f_sign, False, False, 0)

            self.stack.add_titled(page, "page_target", tr("tab_target"))
            self.apply_target_visibility()
            self.refresh_compat_hint()

        def _desc_common(self, box, text):
            d = Gtk.Label(xalign=0.0)
            d.set_markup("<i>%s</i>" % GLib.markup_escape_text(text))
            d.set_line_wrap(True)
            d.set_max_width_chars(76)
            box.pack_start(d, False, False, 0)

        def apply_target_visibility(self):
            """Show only the option groups relevant to the chosen target."""
            t = self.spec.get("target")
            android = t in ("apk", "aab")
            ios = t == "ipa"
            win = t in ("exe", "msi")
            sign = android or ios or win
            for w, vis in ((self.f_android, android), (self.f_ios, ios),
                           (self.f_win, win), (self.f_sign, sign),
                           (self.box_sign_android, android),
                           (self.box_sign_win, win),
                           (self.split_abis, t == "apk")):
                try:
                    w.set_visible(bool(vis))
                except Exception:
                    pass
            self.lbl_target_desc.set_text(tr("desc_" + t))

        def on_out_chosen(self, w):
            self.spec["out"] = w.get_filename() or DEFAULT_OUT
            self.save_spec()

        def on_ks_chosen(self, w):
            self.spec["keystore"] = w.get_filename() or ""
            self.save_spec()

        def on_pfx_chosen(self, w):
            self.spec["win_pfx"] = w.get_filename() or ""
            self.save_spec()

        def set_alias(self, v):
            self.spec["ks_alias"] = v.strip()
            self.save_spec()

        def set_ios_cert(self, v):
            self.spec["ios_cert"] = v.strip()
            self.save_spec()

        def set_ios_prov(self, v):
            self.spec["ios_prov"] = v.strip()
            self.save_spec()

        def on_target_changed(self, i):
            self.spec["target"] = TARGETS[max(0, min(i, len(TARGETS) - 1))]
            self.save_spec()
            self.apply_target_visibility()
            self.refresh_compat_hint()
            self.refresh_command()

        def on_mode_changed(self, i):
            self.spec["mode"] = "release" if i == 0 else "debug"
            self.save_spec()
            self.refresh_command()

        def on_compat_preset(self, i):
            name = COMPAT_PRESETS[max(0, min(i, len(COMPAT_PRESETS) - 1))]
            self.spec["compat_preset"] = name
            self.spec.update(compat_preset(name))
            self._sync_compat_ui()
            self.save_spec()
            self.refresh_compat_hint()
            self.refresh_command()

        def _sync_compat_ui(self):
            try:
                self.sdk_scale.set_value(int(self.spec.get("min_sdk", 21)))
                self.legacy.set_active(bool(self.spec.get("legacy")))
                self.c_ios.set_active(max(0, IOS_VERSIONS.index(
                    self.spec.get("ios_min", "12.0"))))
                self.c_win.set_active(["x64", "x86", "both"].index(
                    self.spec.get("win_arch", "x64")))
                self.c_winmin.set_active(max(0, WIN_VERSIONS.index(
                    self.spec.get("win_min", "10"))))
            except Exception:
                pass

        def on_sign_preset(self, i):
            name = SIGN_PRESETS[max(0, min(i, len(SIGN_PRESETS) - 1))]
            self.spec["sign_preset"] = name
            self.spec.update(sign_preset(name))
            try:
                self.c_mode.set_active(
                    0 if self.spec["mode"] == "release" else 1)
            except Exception:
                pass
            self.save_spec()
            self.refresh_command()

        def on_legacy_changed(self, v):
            self.spec["legacy"] = bool(v)
            la = legacy_android(self.spec)
            self.spec["min_sdk"] = la["min_sdk"]
            self.spec["abis"] = la["abis"]
            try:
                self.sdk_scale.set_value(la["min_sdk"])
            except Exception:
                pass
            self.save_spec()
            self.refresh_compat_hint()
            self.refresh_command()

        def set_min_sdk(self, v):
            self.spec["min_sdk"] = v
            self.save_spec()
            self.refresh_compat_hint()

        def on_split_changed(self, v):
            self.spec["split_abis"] = bool(v)
            self.save_spec()
            self.refresh_command()

        def on_r8_changed(self, v):
            self.spec["r8"] = bool(v)
            self.save_spec()
            self.refresh_command()

        def on_onefile_changed(self, v):
            self.spec["onefile"] = bool(v)
            self.save_spec()
            self.refresh_command()

        def on_ios_min(self, i):
            self.spec["ios_min"] = IOS_VERSIONS[max(0, min(i,
                                                len(IOS_VERSIONS) - 1))]
            self.save_spec()
            self.refresh_compat_hint()
            self.refresh_command()

        def on_ios_devices(self, i):
            self.spec["ios_devices"] = ["iphone", "ipad", "both"][
                max(0, min(i, 2))]
            self.save_spec()
            self.refresh_compat_hint()

        def on_win_arch(self, i):
            self.spec["win_arch"] = ["x64", "x86", "both"][max(0, min(i, 2))]
            self.save_spec()
            self.refresh_compat_hint()
            self.refresh_command()

        def on_win_min(self, i):
            self.spec["win_min"] = WIN_VERSIONS[max(0, min(i,
                                               len(WIN_VERSIONS) - 1))]
            self.save_spec()
            self.refresh_compat_hint()
            self.refresh_command()

        def on_installer(self, i):
            self.spec["win_installer"] = ["portable", "nsis", "msi"][
                max(0, min(i, 2))]
            if i == 2:
                self.spec["target"] = "msi"
                try:
                    self.c_target.set_active(TARGETS.index("msi"))
                except Exception:
                    pass
                self.apply_target_visibility()
            self.save_spec()
            self.refresh_command()

        def refresh_compat_hint(self):
            if not getattr(self, "_ui_ready", False):
                return
            t = self.spec.get("target")
            lines = []
            if t in ("apk", "aab"):
                la = legacy_android(self.spec)
                try:
                    self.lbl_android_name.set_text(
                        tr("hint_android_name") % android_name(la["min_sdk"]))
                except Exception:
                    pass
                lines.append(tr("hint_android") % (
                    la["min_sdk"], ", ".join(la["abis"]),
                    self.spec.get("target_sdk"), tc("agp", "?"),
                    tc("gradle", "?"), tc("jdk", "?")))
            if t == "ipa":
                lines.append(tr("hint_ios") % (self.spec.get("ios_min"),
                                               tr("ios_dev_" +
                                                  self.spec.get(
                                                      "ios_devices",
                                                      "iphone"))))
                if not shutil.which("xcodebuild"):
                    lines.append(tr("hint_ios_mac"))
            if t in ("exe", "msi"):
                lines.append(tr("hint_win") % (", ".join(
                    legacy_windows(self.spec)), self.spec.get("win_min")))
                if not shutil.which("wine"):
                    lines.append(tr("hint_win_wine"))
            self.lbl_legacy.set_text("\n".join(lines) or tr("hint_none"))
            self.refresh_command()

        # ---------- Page 3: BUILD ----------
        def build_build_page(self):
            page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
            page.set_margin_top(6)
            f, box = self.card(tr("bld_frame"))
            self.lbl_cmd = Gtk.Label(xalign=0.0)
            self.lbl_cmd.set_line_wrap(True)
            self.lbl_cmd.set_max_width_chars(88)
            self.lbl_cmd.set_selectable(True)
            self.lbl_cmd.get_style_context().add_class("bld-log")
            box.pack_start(self.lbl_cmd, False, False, 0)
            self.lbl_missing = Gtk.Label(xalign=0.0)
            self.lbl_missing.set_line_wrap(True)
            self.lbl_missing.set_max_width_chars(88)
            box.pack_start(self.lbl_missing, False, False, 0)
            page.pack_start(f, False, False, 0)

            act = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            act.set_halign(Gtk.Align.CENTER)
            act.set_margin_top(6)
            self.btn_build = Gtk.Button(label=tr("bld_start"))
            self.btn_build.get_style_context().add_class("suggested-action")
            self.btn_build.set_tooltip_text(tr("bld_start_help"))
            self.btn_build.connect("clicked", lambda _b: self.start_build())
            self.btn_stop = Gtk.Button(label=tr("bld_stop"))
            self.btn_stop.set_sensitive(False)
            self.btn_stop.connect("clicked", lambda _b: self.stop_build())
            self.btn_open = Gtk.Button(label=tr("bld_open_out"))
            self.btn_open.connect("clicked", lambda _b: self.open_out())
            for b in (self.btn_build, self.btn_stop, self.btn_open):
                act.pack_start(b, False, False, 0)
            page.pack_start(act, False, False, 0)

            self.build_bar = Gtk.ProgressBar()
            self.build_bar.set_show_text(True)
            self.build_bar.set_fraction(0.0)
            self.build_bar.set_margin_start(10)
            self.build_bar.set_margin_end(10)
            self.build_bar.set_margin_top(8)
            page.pack_start(self.build_bar, False, False, 0)

            f2, box2 = self.card(tr("bld_log"))
            sw = Gtk.ScrolledWindow()
            sw.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
            sw.set_size_request(-1, 300)
            self.tv = Gtk.TextView()
            self.tv.set_editable(False)
            self.tv.set_monospace(True)
            self.tv.set_direction(Gtk.TextDirection.LTR)
            self.tv.get_style_context().add_class("bld-log")
            self.buf = self.tv.get_buffer()
            sw.add(self.tv)
            box2.pack_start(sw, True, True, 0)
            page.pack_start(f2, True, True, 0)
            self.stack.add_titled(page, "page_build", tr("tab_build"))
            self.refresh_command()

        def refresh_command(self):
            if not getattr(self, "_ui_ready", False):
                return
            steps = build_steps(self.spec)
            if not steps:
                self.lbl_cmd.set_text(tr("bld_no_cmd"))
            else:
                self.lbl_cmd.set_text("\n".join(
                    "(cd %s && %s)" % (s["cwd"], " ".join(s["argv"]))
                    for s in steps))
            miss = missing_tools(self.spec)
            if miss:
                self.lbl_missing.set_markup(
                    '<span foreground="#ffb0b0">%s</span>'
                    % GLib.markup_escape_text(tr("bld_missing")
                                              % ", ".join(miss)))
            else:
                self.lbl_missing.set_markup(
                    '<span foreground="#8ce0b0">%s</span>'
                    % GLib.markup_escape_text(tr("bld_ready")))

        def append_log(self, line, kind="out"):
            if not self._alive:
                return False
            tag = None
            if kind == "cmd":
                line = "\n$ " + line[2:] if line.startswith("$ ") else line
            self.buf.insert(self.buf.get_end_iter(), line + "\n")
            adj = self.tv.get_parent()
            try:
                adj.get_vadjustment().set_value(
                    adj.get_vadjustment().get_upper())
            except Exception:
                pass
            return False

        def set_build_progress(self, frac, text=""):
            if not self._alive:
                return False
            if frac is None:
                self.build_bar.set_text("")
                self.build_bar.pulse()
            else:
                frac = max(0.0, min(1.0, float(frac)))
                self.build_bar.set_fraction(frac)
                self.build_bar.set_text(text or ("%d%%" % round(frac * 100)))
            return False

        def start_build(self):
            if self._building:
                return
            errs = spec_problems(self.spec)
            if errs:
                self.notify_center("err", tr("bld_invalid"),
                                   "\n".join(tr("err_" + e) for e in errs),
                                   [(tr("up_close"), "", None)])
                return
            steps = build_steps(self.spec)
            if not steps:
                self.notify_center("err", tr("bld_invalid"),
                                   tr("bld_no_cmd"),
                                   [(tr("up_close"), "", None)])
                return
            try:
                os.makedirs(self.spec.get("out") or DEFAULT_OUT, exist_ok=True)
            except Exception as e:
                log("cannot create output dir: %s" % e)
            self._building = True
            self._build_stop = threading.Event()
            self.btn_build.set_sensitive(False)
            self.btn_stop.set_sensitive(True)
            self.buf.set_text("")
            self.set_build_progress(0.0)
            self.append_log(tr("bld_begin") % (tr("kind_" +
                                                  self.spec["kind"]),
                                               tr("tgt_" +
                                                  self.spec["target"])),
                            "cmd")
            self._build_t0 = time.time()
            self._build_ui = 0.0
            self.timers.append(GLib.timeout_add(120, self.pulse_if_idle))

            def on_line(line, kind):
                GLib.idle_add(self.append_log, line, kind)

            def on_progress(frac, line):
                now = time.time()
                if now - self._build_ui < 0.08 and frac < 1.0:
                    return
                self._build_ui = now
                self._last_real_frac = frac
                GLib.idle_add(self.set_build_progress, frac)

            def work():
                env = {"BUILDING_VERSION": self.spec.get("version", "1.0.0"),
                       "BUILDING_NAME": self.spec.get("name", "app")}
                ok, idx, tail = run_steps(
                    steps, on_line=on_line, on_progress=on_progress,
                    should_stop=self._build_stop.is_set, env_extra=env)
                GLib.idle_add(self.build_done, ok, idx, tail)
            threading.Thread(target=work, daemon=True).start()

        def pulse_if_idle(self):
            """Only pulse while the toolchain reports no real percentage."""
            if not self._alive or not self._building:
                return False
            if getattr(self, "_last_real_frac", None) is None:
                self.build_bar.pulse()
            return True

        def stop_build(self):
            if getattr(self, "_build_stop", None):
                self._build_stop.set()
                self.btn_stop.set_sensitive(False)
                self.toast(tr("bld_stopping"))

        def build_done(self, ok, idx, tail):
            self._building = False
            self._last_real_frac = None
            self.btn_build.set_sensitive(True)
            self.btn_stop.set_sensitive(False)
            secs = int(time.time() - getattr(self, "_build_t0", time.time()))
            log("build %s in %ds (step %d)" % ("ok" if ok else "failed",
                                               secs, idx))
            if ok:
                self.set_build_progress(1.0)
                arts = artifact_names(self.spec)
                self.notify_center(
                    "ok", tr("bld_done"),
                    tr("bld_done_body") % (tr("tgt_" + self.spec["target"]),
                                           secs) + "\n" +
                    (tr("bld_artifacts") % ", ".join(arts) if arts else ""),
                    [(tr("bld_open_out"), "suggested-action", self.open_out),
                     (tr("up_close"), "", None)])
            else:
                self.set_build_progress(0.0)
                self.notify_center(
                    "err", tr("bld_fail"),
                    (tr("bld_fail_body") % (idx + 1)) + "\n\n" +
                    "\n".join((tail or "").splitlines()[-12:]),
                    [(tr("up_close"), "", None)])
                self.report_error("build", (tail or "")[-200:])
            return False

        def open_out(self):
            out = self.spec.get("out") or DEFAULT_OUT
            try:
                os.makedirs(out, exist_ok=True)
                subprocess.Popen(["xdg-open", out])
            except Exception as e:
                self.toast(str(e))

        # ---------- Page 4: UPDATE CENTER ----------
        def build_update_page(self):
            page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
            page.set_margin_top(6)
            f, box = self.card(tr("upd_frame"))
            self.lbl_cur = Gtk.Label(xalign=0.0)
            self.lbl_cur.set_markup("%s: <b>%s</b>"
                                    % (GLib.markup_escape_text(
                                        tr("upd_current")), APP_VERSION))
            box.pack_start(self.lbl_cur, False, False, 0)
            for k, v in (("upd_server", REPO), ("upd_channel", UPDATE_REF)):
                l = Gtk.Label(xalign=0.0)
                l.set_markup("%s: <b>%s</b>"
                             % (GLib.markup_escape_text(tr(k)),
                                GLib.markup_escape_text(v)))
                box.pack_start(l, False, False, 0)
            self.lbl_last = Gtk.Label(xalign=0.0)
            self.lbl_last.set_text("%s: %s" % (tr("upd_last"),
                                               tr("upd_never")))
            box.pack_start(self.lbl_last, False, False, 0)
            self.lbl_note = Gtk.Label(xalign=0.0)
            self.lbl_note.set_line_wrap(True)
            self.lbl_note.set_max_width_chars(64)
            self.lbl_note.set_text("")
            box.pack_start(self.lbl_note, False, False, 0)
            page.pack_start(f, False, False, 0)

            act = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            act.set_halign(Gtk.Align.CENTER)
            act.set_margin_top(10)
            act.set_margin_bottom(6)
            self.btn_upd = Gtk.Button(label=tr("upd_btn"))
            self.btn_upd.get_style_context().add_class("suggested-action")
            self.btn_upd.set_tooltip_text(tr("upd_btn_help"))
            self.btn_upd.connect("clicked", lambda _b: self._upd_manual())
            auto = Gtk.CheckButton(label=tr("upd_auto"))
            auto.set_active(bool(self.config.get("auto_update_check", True)))
            auto.connect("toggled", self.on_auto_toggled)
            for w in (self.btn_upd, auto):
                act.pack_start(w, False, False, 0)
            page.pack_start(act, False, False, 0)

            f2, rbox = self.card(tr("upd_routes"))
            self.route_list = Gtk.ListBox()
            self.route_list.set_selection_mode(Gtk.SelectionMode.NONE)
            fr = Gtk.Frame()
            fr.add(self.route_list)
            rbox.pack_start(fr, False, False, 0)
            page.pack_start(f2, False, False, 0)
            self._upd_routes_ui([])
            self.stack.add_titled(page, "page_update", tr("tab_update"))

        def on_auto_toggled(self, w):
            self.config["auto_update_check"] = bool(w.get_active())
            save_config(self.config)

        def _upd_route_row(self, url, ok, ms, err):
            row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
            for m in ("start", "end"):
                getattr(row, "set_margin_" + m)(8)
            row.set_margin_top(3)
            row.set_margin_bottom(3)
            if ok is None:
                ic, txt = "dialog-question", tr("upd_route_untested")
            elif ok:
                ic, txt = "emblem-default", tr("upd_route_ok") % ms
            else:
                ic, txt = "dialog-error", tr("upd_route_fail")
            row.pack_start(Gtk.Image.new_from_icon_name(ic, Gtk.IconSize.MENU),
                           False, False, 0)
            lab = Gtk.Label(xalign=0.0)
            lab.set_markup("<small>%s</small>"
                           % GLib.markup_escape_text(url[:78]))
            st = Gtk.Label(xalign=1.0)
            st.set_markup("<small><b>%s</b></small>"
                          % GLib.markup_escape_text(txt))
            st.set_tooltip_text(err or "")
            row.pack_start(lab, True, True, 0)
            row.pack_end(st, False, False, 0)
            return row

        def _upd_routes_ui(self, routes):
            if not self._alive:
                return False
            for ch in self.route_list.get_children():
                self.route_list.remove(ch)
            for (u, ok, ms, err) in (routes or []):
                self.route_list.add(self._upd_route_row(u, ok, ms, err))
            if not routes:
                for u in UPDATE_ENDPOINTS:
                    self.route_list.add(self._upd_route_row(u, None, 0, ""))
            self.route_list.show_all()
            return False

        def _upd_check_later(self):
            threading.Thread(target=self._upd_fetch, daemon=True).start()
            return False

        def _upd_manual(self):
            if getattr(self, "_upd_busy", False):
                self.toast(tr("up_busy"))
                return
            self._upd_busy = True
            self.btn_upd.set_sensitive(False)
            self.toast(tr("up_checking"))
            threading.Thread(target=self._upd_fetch, args=(True,),
                             daemon=True).start()

        def _upd_fetch(self, manual=False):
            info, routes = upd_fetch_manifest()
            GLib.idle_add(self._upd_routes_ui, routes)
            GLib.idle_add(self._upd_stamp)
            if info is None:
                if manual:
                    GLib.idle_add(self._upd_check_done, False, True)
                return
            GLib.idle_add(self._upd_result, info)
            if manual:
                GLib.idle_add(self._upd_check_done, True, False)

        def _upd_stamp(self):
            if not self._alive:
                return False
            self.lbl_last.set_text("%s: %s" % (
                tr("upd_last"), datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
            return False

        def _upd_check_done(self, ok, net_err):
            self._upd_busy = False
            if self._alive:
                self.btn_upd.set_sensitive(True)
            if net_err:
                self.toast(tr("up_check_fail"))
            elif ok and getattr(self, "_upd_pending", None) is None:
                self.toast(tr("up_up_to_date") % APP_VERSION)

        def _upd_result(self, info):
            if not self._alive:
                return
            try:
                new_v = str(info.get("version", "0"))
                if not _ver_gt(new_v, APP_VERSION):
                    return
            except Exception:
                return
            self._upd_pending = (new_v, info)
            self.toast(tr("up_found"))
            body = tr("up_found_body") % new_v
            note = str(info.get("note", ""))
            if note:
                body = body + "\n\n" + note
            self._upd_card_open(info, new_v, body)
            self.desktop_notify(tr("up_found"), body.split("\n")[0])

        def _upd_card_open(self, info, ver, body):
            """One centre-of-screen card: info section + (hidden) progress
            section in the SAME box. "update now" swaps to the progress view
            and, when done, the card restarts the tool automatically."""
            self._upd_progress_close()
            w, card = self._new_card_window(tr("up_found"))
            info_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
            top = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            badge = Gtk.Label(label="!")
            badge.get_style_context().add_class("bld-notify-badge")
            badge.set_size_request(34, 34)
            top.pack_start(badge, False, False, 0)
            tl = Gtk.Label(xalign=0.0)
            tl.get_style_context().add_class("bld-notify-title")
            tl.set_markup("<b>%s</b>" % GLib.markup_escape_text(tr("up_found")))
            top.pack_start(tl, True, True, 0)
            info_box.pack_start(top, False, False, 0)
            bl = Gtk.Label(xalign=0.0, label=body)
            bl.get_style_context().add_class("bld-notify-body")
            bl.set_line_wrap(True)
            bl.set_max_width_chars(56)
            bl.set_selectable(True)
            info_box.pack_start(bl, False, False, 0)
            card.pack_start(info_box, False, False, 0)

            prog_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
            stage = Gtk.Label(xalign=0.0)
            stage.get_style_context().add_class("bld-notify-body")
            stage.set_text(tr("up_progress_stage_dl"))
            prog_box.pack_start(stage, False, False, 0)
            bar = Gtk.ProgressBar()
            bar.set_show_text(True)
            bar.set_fraction(0.0)
            bar.set_text("0%")
            prog_box.pack_start(bar, False, False, 0)
            detail = Gtk.Label(xalign=0.0)
            detail.get_style_context().add_class("bld-notify-body")
            detail.set_text("")
            prog_box.pack_start(detail, False, False, 0)
            cancel = Gtk.Button(label=tr("up_progress_cancel"))
            cancel.set_halign(Gtk.Align.CENTER)
            cancel.connect("clicked", lambda _b: self._upd_cancel_now())
            prog_box.pack_start(cancel, False, False, 0)
            prog_box.set_no_show_all(True)
            prog_box.set_visible(False)
            card.pack_start(prog_box, False, False, 0)

            btns = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            btns.set_halign(Gtk.Align.CENTER)
            now = Gtk.Button(label=tr("up_now"))
            now.get_style_context().add_class("suggested-action")
            now.connect("clicked",
                        lambda _b: self._upd_begin_progress(
                            info.get("deb", ""), ver))
            later = Gtk.Button(label=tr("up_later"))
            later.connect("clicked", lambda _b: self._upd_progress_close())
            btns.pack_start(now, False, False, 0)
            btns.pack_start(later, False, False, 0)
            info_box.pack_start(btns, False, False, 0)

            w.show_all()
            self._center_on_screen(w)
            try:
                w.present()
            except Exception:
                pass
            self._upd_prog = {"win": w, "bar": bar, "detail": detail,
                              "cancel": cancel, "stage": stage,
                              "info": info_box, "prog": prog_box,
                              "t": time.time(), "bytes": 0}
            self._upd_cancel_evt = threading.Event()
            return w

        def _upd_begin_progress(self, deb, ver):
            st = getattr(self, "_upd_prog", None)
            if st:
                st["info"].set_visible(False)
                st["prog"].set_visible(True)
            self._upd_start(deb, ver)

        # ---------- CENTER-OF-SCREEN CARD ----------
        def _new_card_window(self, title):
            w = Gtk.Window()
            w.set_decorated(False)
            w.set_resizable(False)
            w.set_keep_above(True)
            w.set_skip_taskbar_hint(True)
            w.set_skip_pager_hint(True)
            w.set_position(Gtk.WindowPosition.CENTER)
            w.set_title(title)
            try:
                w.set_type_hint(Gdk.WindowTypeHint.DIALOG)
            except Exception:
                pass
            card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
            card.get_style_context().add_class("bld-notify")
            card.set_size_request(500, -1)
            for m, v in (("start", 22), ("end", 22), ("top", 20),
                         ("bottom", 18)):
                getattr(card, "set_margin_" + m)(v)
            w.add(card)
            return w, card

        def notify_center(self, kind, title, body, actions):
            """A card notification in the MIDDLE OF THE SCREEN."""
            if not self._alive:
                return None
            w, card = self._new_card_window(title)
            top = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            badge = Gtk.Label(label="!")
            badge.get_style_context().add_class("bld-notify-badge")
            badge.set_size_request(34, 34)
            top.pack_start(badge, False, False, 0)
            tl = Gtk.Label(xalign=0.0)
            tl.get_style_context().add_class("bld-notify-title")
            if kind == "ok":
                tl.get_style_context().add_class("bld-notify-title-ok")
            elif kind == "err":
                tl.get_style_context().add_class("bld-notify-title-err")
            tl.set_markup("<b>%s</b>" % GLib.markup_escape_text(title))
            top.pack_start(tl, True, True, 0)
            card.pack_start(top, False, False, 0)

            bl = Gtk.Label(xalign=0.0, label=body)
            bl.get_style_context().add_class("bld-notify-body")
            bl.set_line_wrap(True)
            bl.set_max_width_chars(56)
            bl.set_selectable(True)
            card.pack_start(bl, False, False, 0)

            btns = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            btns.set_halign(Gtk.Align.CENTER)
            btns.set_margin_top(4)

            def close_win():
                try:
                    w.destroy()
                except Exception:
                    pass
            for (label, style, cb) in actions:
                b = Gtk.Button(label=label)
                if style:
                    b.get_style_context().add_class(style)
                b.connect("clicked",
                          lambda _b, c=cb: (close_win(), c and c()))
                btns.pack_start(b, False, False, 0)
            card.pack_start(btns, False, False, 0)
            w.show_all()
            self._center_on_screen(w)
            try:
                w.present()
            except Exception:
                pass
            return w

        def _center_on_screen(self, win):
            try:
                nat = win.get_preferred_size()[1]
                ww = max(1, int(nat.width))
                hh = max(1, int(nat.height))
                disp = Gdk.Display.get_default()
                try:
                    mon = disp.get_primary_monitor()
                except Exception:
                    mon = None
                if mon is None:
                    mon = disp.get_monitor(0)
                g = mon.get_geometry()
                win.move(int(g.x + (g.width - ww) / 2),
                         int(g.y + (g.height - hh) / 2))
            except Exception as e:
                log("center on screen failed: %s" % e)

        def desktop_notify(self, title, body):
            if not self.config.get("notify_desktop", True):
                return
            try:
                ns = shutil.which("notify-send")
                if ns:
                    subprocess.run([ns, "-u", "critical", title, body],
                                   capture_output=True, timeout=15)
            except Exception as e:
                log("desktop notify failed: %s" % e)

        # ---------- REAL PROGRESS CARD (update download/install) ----------
        def _upd_cancel_now(self):
            ev = getattr(self, "_upd_cancel_evt", None)
            if ev is not None:
                ev.set()
            st = getattr(self, "_upd_prog", None)
            if st:
                st["cancel"].set_sensitive(False)
                st["cancel"].set_label(tr("up_progress_cancelling"))
            self.toast(tr("up_progress_cancelling"))

        def _upd_progress_set(self, frac, detail="", stage=""):
            st = getattr(self, "_upd_prog", None)
            if not st or not self._alive:
                return False
            bar = st["bar"]
            if frac is None:
                bar.set_text("")
                bar.pulse()
            else:
                frac = max(0.0, min(1.0, float(frac)))
                bar.set_fraction(frac)
                bar.set_text("%d%%" % round(frac * 100))
            if detail:
                st["detail"].set_text(detail)
            if stage:
                st["stage"].set_text(stage)
                st["cancel"].set_sensitive(False)
            return False

        def _upd_progress_close(self):
            st = getattr(self, "_upd_prog", None)
            if st:
                self._upd_prog = None
                try:
                    st["win"].destroy()
                except Exception:
                    pass

        def _upd_progress_detail(self, done, total, speed):
            s = (tr("up_progress_bytes") % (done / 1048576.0,                                            total / 1048576.0)) if total \
                else (tr("up_progress_bytes_unknown") % (done / 1048576.0,))
            if speed > 0:
                s = s + "  -  " + (tr("up_progress_speed") % speed)
            return s

        # ---------- DOWNLOAD + INSTALL + AUTO-RESTART (same card) ----------
        def _upd_start(self, deb, ver):
            if not deb:
                self._upd_fail(tr("up_fail"), tr("up_no_deb"))
                return
            if not getattr(self, "_upd_prog", None):
                self._upd_card_open({"deb": deb, "note": ""}, ver,
                                    tr("up_found_body") % ver)
                st = self._upd_prog
                st["info"].set_visible(False)
                st["prog"].set_visible(True)
            self.toast(tr("up_downloading") % ver)
            self._upd_progress_set(0.0, "", tr("up_progress_stage_dl"))

            def work():
                st = self._upd_prog
                ui_at = [0.0]

                def prog(done, total):
                    now = time.time()
                    if now - ui_at[0] < 0.09 and (not total or done < total):
                        return
                    ui_at[0] = now
                    speed = 0.0
                    if now - st["t"] > 0.15:
                        speed = max(0.0, done - st["bytes"]) / (now - st["t"])                             / 1048576.0
                        st["t"], st["bytes"] = now, done
                    frac = (done / float(total)) if total else None
                    GLib.idle_add(self._upd_progress_set, frac,
                                  self._upd_progress_detail(done, total,
                                                            speed))
                ev = getattr(self, "_upd_cancel_evt", None)
                ok, size, err = upd_download(
                    deb=deb, dest=UPDATE_DEB_TMP, progress=prog,
                    should_stop=ev.is_set if ev else None)
                if not ok:
                    if err == "cancelled":
                        GLib.idle_add(self._upd_progress_close)
                        GLib.idle_add(self.toast, tr("up_progress_cancelled"))
                    else:
                        GLib.idle_add(self._upd_fail, tr("up_dl_fail"), err)
                    return
                GLib.idle_add(self._upd_progress_set, 1.0)
                if not upd_is_deb(UPDATE_DEB_TMP):
                    log("not a .deb: %s" % UPDATE_DEB_TMP)
                    GLib.idle_add(self._upd_fail, tr("up_bad_deb"),
                                  UPDATE_DEB_TMP)
                    return
                log("update downloaded %d bytes" % size)
                GLib.idle_add(self._upd_install, UPDATE_DEB_TMP, ver)
            threading.Thread(target=work, daemon=True).start()

        def _upd_install(self, dest, ver):
            self.toast(tr("up_installing"))
            self._upd_progress_set(None, "", tr("up_progress_stage_inst"))

            def work():
                def prog(frac, _line):
                    GLib.idle_add(self._upd_progress_set, frac, "",
                                  tr("up_progress_stage_inst"))
                ok, out = upd_apply_data(dest, progress=prog)
                GLib.idle_add(self._upd_installed, ok, out, ver)
            threading.Thread(target=work, daemon=True).start()

        def _upd_installed(self, ok, out, ver):
            if ok:
                self._upd_progress_set(1.0, tr("up_restart_soon"),
                                       tr("up_done"))
                self.toast(tr("up_done") + " " + ver)
                self.timers.append(GLib.timeout_add(1800, self._auto_restart))
            else:
                self._upd_fail(tr("up_fail"), out)

        def _auto_restart(self):
            self._upd_progress_close()
            self._restart()
            return False

        def _restart(self):
            try:
                if os.path.isfile(LAUNCHER) and os.access(LAUNCHER, os.X_OK):
                    os.execv(LAUNCHER, [LAUNCHER])
            except Exception:
                pass
            try:
                os.execv(sys.executable, [sys.executable] + list(sys.argv))
            except Exception:
                pass

        def _upd_fail(self, title, msg=""):
            log("update failed: %s %s" % (title, msg))
            self._upd_progress_close()
            self.notify_center(
                "err", title,
                str(msg) + "\n\n" + tr("up_manual") +
                "\nsudo apt install %s" % UPDATE_DEB_TMP,
                [(tr("up_close"), "", None)])
            self.report_error("update", str(msg)[:200])

        # ---------- Page 5: About / doctor ----------
        def build_about_page(self):
            page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
            page.set_margin_top(6)
            f, box = self.card(tr("about_frame"))
            for k, v in (("upd_current", APP_VERSION),
                         ("about_python", sys.version.split()[0]),
                         ("about_gtk", "%d.%d.%d" % (Gtk.get_major_version(),
                                                     Gtk.get_minor_version(),
                                                     Gtk.get_micro_version())),
                         ("about_repo", REPO)):
                l = Gtk.Label(xalign=0.0)
                l.set_markup("%s: <b>%s</b>"
                             % (GLib.markup_escape_text(tr(k)),
                                GLib.markup_escape_text(v)))
                box.pack_start(l, False, False, 0)
            ab = Gtk.Label(xalign=0.0)
            ab.set_line_wrap(True)
            ab.set_max_width_chars(70)
            ab.set_text(tr("about_body"))
            box.pack_start(ab, False, False, 0)
            page.pack_start(f, False, False, 0)

            act = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            act.set_halign(Gtk.Align.CENTER)
            act.set_margin_top(10)
            for label, tip, cb in ((tr("btn_doctor"), "doctor_help",
                                    self.run_doctor),
                                   (tr("btn_log"), "log_help", self.show_log),
                                   (tr("btn_about"), "about_help",
                                    self.show_about)):
                b = Gtk.Button(label=label)
                b.set_tooltip_text(tr(tip))
                b.connect("clicked", lambda _b, c=cb: c())
                act.pack_start(b, False, False, 0)
            page.pack_start(act, False, False, 0)
            self.stack.add_titled(page, "page_about", tr("tab_about"))

        def run_doctor(self):
            def work():
                lines = ["Building doctor %s" % APP_VERSION, "=" * 46,
                         "pinned toolchains: %s" % json.dumps(
                             _TOOLCHAINS, ensure_ascii=False)[:400],
                         "-" * 46]
                for name, path, ver in toolchain_report():
                    lines.append("%-12s %s  %s" % (
                        name, ("OK  " if path else "MISS"),
                        (path + "  " if path else "") + ver))
                txt = "\n".join(lines)
                log("doctor:\n" + txt)
                GLib.idle_add(self.show_text, tr("doctor_title"), txt)
            threading.Thread(target=work, daemon=True).start()

        def show_text(self, title, txt):
            if not self._alive:
                return False
            d = Gtk.Dialog(title=title, transient_for=self, modal=True)
            d.set_default_size(720, 460)
            sw = Gtk.ScrolledWindow()
            sw.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
            tv = Gtk.TextView()
            tv.set_editable(False)
            tv.set_monospace(True)
            tv.set_direction(Gtk.TextDirection.LTR)
            tv.get_buffer().set_text(txt)
            sw.add(tv)
            d.get_content_area().pack_start(sw, True, True, 0)
            d.add_button(tr("up_close"), Gtk.ResponseType.CLOSE)
            d.show_all()
            d.run()
            d.destroy()
            return False

        def show_log(self):
            txt = _read(LOG_FILE, tr("log_empty"))[-14000:]
            self.show_text(tr("log_title"), txt or tr("log_empty"))

        def show_about(self):
            d = Gtk.MessageDialog(transient_for=self, modal=True,
                                  message_type=Gtk.MessageType.INFO,
                                  text="%s %s" % (tr("app_title"),
                                                  APP_VERSION))
            d.format_secondary_text(tr("about_body"))
            d.run()
            d.destroy()

        # ---------- AUTO ERROR REPORTING ----------
        def report_error(self, ctx, msg):
            try:
                import hashlib
                os.makedirs(CONFIG_DIR, exist_ok=True)
                rep = os.path.join(CONFIG_DIR, "reported.txt")
                key = hashlib.sha1(("%s|%s" % (ctx, msg)).encode()).hexdigest()
                seen = {}
                if os.path.isfile(rep):
                    for line in _read(rep).splitlines():
                        p = line.split()
                        if len(p) == 2:
                            seen[p[1]] = float(p[0])
                if key in seen and time.time() - seen[key] < 86400:
                    return
                seen[key] = time.time()
                with open(rep, "w") as f:
                    for k, v in seen.items():
                        f.write("%s %s\n" % (v, k))
                tail = "\n".join(_read(LOG_FILE).splitlines()[-40:])
                import platform
                body = "version: %s\ncontext: %s\nplatform: %s\n\n%s\n\n--- log ---\n%s" % (
                    APP_VERSION, ctx, platform.platform(), msg, tail)
                local = os.path.join(
                    CONFIG_DIR, "error_report_%s.txt"
                    % datetime.now().strftime("%Y%m%d_%H%M%S"))
                with open(local, "w", encoding="utf-8") as f:
                    f.write(body)
                sent = False
                gh = shutil.which("gh")
                if gh:
                    try:
                        p = subprocess.run(
                            [gh, "api", "repos/%s/issues" % REPO,
                             "-f", "title=auto-report [%s] %s"
                                   % (ctx, APP_VERSION),
                             "-f", "body=" + body],
                            capture_output=True, text=True, timeout=45)
                        sent = p.returncode == 0
                    except Exception:
                        pass
                if not sent:
                    try:
                        p = subprocess.run(
                            ["curl", "-s", "-F", "file=@%s" % local,
                             "https://0x0.st"],
                            capture_output=True, text=True, timeout=45)
                        sent = p.returncode == 0
                    except Exception:
                        pass
                log("report_error %s sent=%s local=%s" % (ctx, sent, local))
                self.toast(tr("err_sent") if sent else tr("err_saved"))
            except Exception as e:
                log("report_error failed: %s" % e)


def main():
    load_locale()
    load_toolchains()
    if "--doctor" in sys.argv:
        print("Building doctor %s" % APP_VERSION)
        print("pygobject:", "OK" if GTK_OK else "MISSING (%s)" % _ERR)
        print("locale:", load_locale() or "MISSING")
        print("toolchains:", load_toolchains() or "MISSING")
        for name, path, ver in toolchain_report():
            print("%-12s %s %s" % (name, "OK  " if path else "MISS", ver))
        info, routes = upd_fetch_manifest()
        for (u, ok, ms, err) in routes:
            print("route", "OK " if ok else "FAIL", "%dms" % ms, u[:70], err)
        print("server version:", info.get("version") if info else "unreachable")
        return 0
    if "--selftest" in sys.argv:
        d = detect_project(sys.argv[-1] if len(sys.argv) > 2 else ".")
        print("detect:", d["kind"], d["evidence"], d["targets"])
        sp = default_spec(d["path"])
        sp.update({"kind": d["kind"], "target": (d["targets"] or ["apk"])[0]})
        for s in build_steps(sp):
            print("cmd:", " ".join(s["argv"]), "  [cwd=%s]" % s["cwd"])
        print("missing tools:", missing_tools(sp))
        return 0
    if not GTK_OK:
        print("GTK unavailable: %s" % _ERR)
        return 1
    log("start %s" % APP_VERSION)
    try:
        w = BuildingWindow()
        w.show_all()
        if "--smoke" in sys.argv:
            GLib.timeout_add(3000, Gtk.main_quit)
        Gtk.main()
        log("clean exit")
    except Exception as e:
        log("fatal: %s" % e)
        traceback.print_exc()
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
