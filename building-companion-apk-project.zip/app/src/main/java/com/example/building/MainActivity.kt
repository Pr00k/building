package com.example.building

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * Building Companion - a minimal, buildable Android app.
 * Open this project in Android Studio (or run `gradle assembleRelease`)
 * to produce the APK. It is a companion/launcher front-end; the heavy
 * build toolchains run on the desktop "Building" app.
 */
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        findViewById<TextView>(R.id.info).text = getString(R.string.info)
    }
}
