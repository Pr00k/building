# Building Companion (APK project)

A minimal, valid Android project that builds to an APK with external tools.
This is a companion front-end; the desktop "Building" tool does the actual builds.

## Build the APK
- Android Studio: Open this folder → Build → Build Bundle(s)/APK(s) → Build APK(s).
- Command line (with Android SDK + JDK 17):
      gradle wrapper            # once, to generate the wrapper
      ./gradlew assembleRelease
  APK output: app/build/outputs/apk/release/app-release-unsigned.apk

## Notes
- applicationId: com.example.building (change as needed)
- minSdk 21, targetSdk/compileSdk 35, Kotlin 2.1.0, AGP 8.7.3, Gradle 8.11.1
